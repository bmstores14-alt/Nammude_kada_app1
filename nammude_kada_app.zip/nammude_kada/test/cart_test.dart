import 'package:flutter_test/flutter_test.dart';
import 'package:nammude_kada/core/providers.dart';
import 'package:nammude_kada/data/models.dart';

Shop shop(int id) => Shop(id: id, name: 'Shop $id', slug: 's$id');
Product product(int id, int shopId, {int price = 100, int? discount, int? stock}) =>
    Product(id: id, shopId: shopId, name: 'P$id', price: price, discountPrice: discount, stockQty: stock);

void main() {
  test('adds items, uses discount price, totals', () {
    final cart = CartNotifier();
    cart.add(shop(1), product(1, 1, price: 100, discount: 80));
    cart.add(shop(1), product(1, 1, price: 100, discount: 80));
    cart.add(shop(1), product(2, 1, price: 50));
    expect(cart.state.count, 3);
    expect(cart.state.subtotal, 80 * 2 + 50);
  });

  test('does not exceed stock', () {
    final cart = CartNotifier();
    cart.add(shop(1), product(1, 1, stock: 2));
    cart.add(shop(1), product(1, 1, stock: 2));
    cart.add(shop(1), product(1, 1, stock: 2));
    expect(cart.state.count, 2);
  });

  test('one shop at a time', () {
    final cart = CartNotifier();
    cart.add(shop(1), product(1, 1));
    expect(cart.canAdd(shop(2)), isFalse);
    cart.add(shop(2), product(2, 2)); // ignored
    expect(cart.state.count, 1);
    cart.clear();
    expect(cart.canAdd(shop(2)), isTrue);
  });

  test('removing the last item empties the cart', () {
    final cart = CartNotifier();
    cart.add(shop(1), product(1, 1));
    cart.setQty(1, 0);
    expect(cart.state.count, 0);
    expect(cart.state.shop, isNull);
  });

  test('mobile number normalisation lives in util (see normalizeMobile)', () {
    // kept as a placeholder for util tests that need no Flutter bindings
    expect(true, isTrue);
  });
}
