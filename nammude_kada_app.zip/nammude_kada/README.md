# Nammude Kada — Android app (Flutter)

Every Small Shop, One Digital Platform. A separate native app that shares the website's Supabase backend
(shops, products, orders, categories, accounts). It does not touch or replace the website.

**Status: first complete draft. It has NOT been compiled or run yet** (the machine it was written on had no Flutter SDK).
Expect a few small compile fixes on the first `flutter run`. The database side (`002_app_support.sql`) was tested.

## 1. Backend first
1. Back up the Supabase project, test on a copy.
2. Run the latest `supabase.sql`, then `002_app_support.sql` (SQL Editor).
3. Supabase → Authentication → Providers → **Phone**: turn on and connect an SMS provider
   (Twilio Verify, or a custom provider through the *Send SMS hook*, e.g. MSG91 — India needs DLT registration).
   Email login stays on (existing shop owners use it in the app too).
4. Import the districts of the other states into `public.districts` (only Kerala is seeded), and add category
   names in the other 8 languages to `categories.name_i18n` (`{"hi": "...", "ta": "..."}`); English shows until then.

## 2. Create the Android project
```bash
flutter create --org store.nammudekada --project-name nammude_kada --platforms android nammude_kada_new
# copy THIS folder's pubspec.yaml, l10n.yaml, analysis_options.yaml, lib/ and test/ over nammude_kada_new
# delete nammude_kada_new/test/widget_test.dart
cd nammude_kada_new
```
The Android package id becomes `store.nammudekada.nammude_kada`. **It can never be changed after the first Play upload**,
so decide now.

### AndroidManifest.xml (android/app/src/main/AndroidManifest.xml)
Inside `<manifest>` (before `<application>`):
```xml
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
<queries>
  <intent><action android:name="android.intent.action.VIEW"/><data android:scheme="https"/></intent>
  <intent><action android:name="android.intent.action.VIEW"/><data android:scheme="tel"/></intent>
</queries>
```
and set `android:label="Nammude Kada"` on `<application>`. (`flutter create` only adds INTERNET to the debug manifest.)

## 3. Keys
Create `env.json` (never commit it):
```json
{ "SUPABASE_URL": "https://YOUR-PROJECT.supabase.co", "SUPABASE_ANON_KEY": "YOUR-ANON-PUBLIC-KEY" }
```
Only the **anon public** key. Never the service_role key.

## 4. Run
```bash
flutter pub get
flutter gen-l10n
flutter run --dart-define-from-file=env.json
flutter test
```

## 5. Push notifications (optional, later)
1. Firebase console → add an Android app with the package id → download `google-services.json` into `android/app/`.
2. Add the Google Services Gradle plugin per the FlutterFire docs. Without this the app still works; alerts simply do not arrive.
3. Server side (not included yet): a Supabase Database Webhook on `INSERT` into `orders` calling an Edge Function that
   reads `device_tokens` of the shop owner and sends the message through the FCM HTTP v1 API.
   Keep the Firebase service-account key in Supabase secrets only.

## 6. Release build
Create a keystore once and **back it up** (losing it can lock you out of updates unless you use Play App Signing):
```bash
keytool -genkey -v -keystore ~/nammude-kada-upload.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload
```
`android/key.properties` (gitignored):
```
storePassword=...
keyPassword=...
keyAlias=upload
storeFile=/absolute/path/nammude-kada-upload.jks
```
Wire it into `android/app/build.gradle(.kts)` (`signingConfigs.release`, see Flutter's "Build and release an Android app"), then:
```bash
flutter build appbundle --release --dart-define-from-file=env.json
# output: build/app/outputs/bundle/release/app-release.aab
```

## 7. Google Play checklist
- **Privacy policy URL**: the website's policy lives at `/#/privacy` (a hash route, rendered by JavaScript). Google's review may not render it.
  Publish a plain static `privacy.html` and use that URL.
- **Account deletion**: the app has Delete my account. Play also requires a **web URL** where users can request deletion without the app
  (e.g. a static page with your support contact). Not built yet.
- **Data safety form**: collected = name, phone number, address (delivery), approximate/precise location (optional, nearby shops and shop position),
  photos (shop owners), order history; encrypted in transit (HTTPS); deletion available. No ads, no data sold.
- **Payments**: the app has no in-app payments on purpose. Selling plans/ads for app features inside the app through UPI/Razorpay can conflict with
  Play's payments policy; keep that on the website unless you review the policy.
- New personal developer accounts may need a closed test (testers for a number of days) before production. Check the current rule in Play Console.
- Target API level and content rating questionnaire: check what Play Console requires at upload time.
- Store listing (icon 512×512, feature graphic 1024×500, phone screenshots, short and full description): to be made from the running app.

## 8. What is built
Customer: browse by category / PIN / town / GPS, shop and product pages, one-shop cart, checkout (pickup or delivery, pay the shop directly),
order history with status and cancel (while new), call / WhatsApp shop. Mobile OTP login (+ email login for existing owners).
Shop owner: free shop registration with state/district/PIN, approval status, orders with live updates, accept/reject/status changes,
call / WhatsApp customer, today's sales, product add/edit/photos(3)/stock, shop settings, GPS location, shop link share.
Account: 10 languages, privacy/terms links, logout, delete account.

## 9. Not built yet
Saved-address picker (table exists), push Edge Function, admin screens for states/districts (website admin), reviewer-friendly deep links
(the website uses `#/` links), crash reporting, more tests, screenshots and store graphics.

## 10. Translations
All 10 languages are written, but **have a native speaker review them** before release (Malayalam, Hindi, Tamil, Kannada, Telugu,
Marathi, Bengali, Gujarati, Punjabi). Strings live in `lib/l10n/app_*.arb`.
