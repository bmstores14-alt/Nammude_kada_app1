import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

import '../data/repo.dart';

/// Push notifications (new order alerts for shop owners).
/// Works only after Firebase is configured (google-services.json, see README). Until then every call is a no-op,
/// so the app still runs without Firebase.
class PushService {
  static bool _ready = false;
  static bool _listening = false;

  static Future<void> init() async {
    try {
      await Firebase.initializeApp();
      _ready = true;
    } catch (_) {
      _ready = false;
    }
  }

  /// Call after login. Stores this phone's token so the server can notify the user.
  static Future<void> register(Repo repo) async {
    if (!_ready) return;
    try {
      final m = FirebaseMessaging.instance;
      await m.requestPermission(); // Android 13+ asks the user
      final token = await m.getToken();
      if (token != null) await repo.registerToken(token);
      if (!_listening) {
        _listening = true;
        m.onTokenRefresh.listen((t) {
          repo.registerToken(t).catchError((_) {});
        });
      }
    } catch (_) {
      // notifications are optional; never block the app
    }
  }
}
