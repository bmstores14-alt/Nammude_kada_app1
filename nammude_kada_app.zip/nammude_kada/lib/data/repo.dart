import 'dart:typed_data';

import 'package:supabase_flutter/supabase_flutter.dart';

import 'models.dart';

/// Every call to the shared Supabase backend lives here.
/// Security is enforced by the database (row level security + functions); this class only asks.
class Repo {
  Repo(this.c);
  final SupabaseClient c;

  String _clean(String s) => s.replaceAll(RegExp(r'[,()%*\\"_]'), ' ').replaceAll(RegExp(r'\s+'), ' ').trim();
  String get _today => DateTime.now().toIso8601String().substring(0, 10);

  // ---------- browse ----------
  Future<List<Category>> categories() async {
    final rows = await c.from('categories').select().eq('active', true).order('sort');
    return rows.map<Category>(Category.fromJson).toList();
  }

  Future<List<Shop>> shops({String text = '', int? categoryId, int limit = 60}) async {
    var q = c.from('shops').select().eq('status', 'approved');
    if (categoryId != null) q = q.eq('category_id', categoryId);
    final t = _clean(text);
    if (t.isNotEmpty) {
      final like = '%$t%';
      final parts = [
        'name.ilike.$like',
        'town.ilike.$like',
        'locality.ilike.$like',
        'district.ilike.$like',
        if (RegExp(r'^\d{6}$').hasMatch(t)) 'pincode.eq.$t',
      ];
      q = q.or(parts.join(','));
    }
    final rows = await q.order('featured_until', ascending: false, nullsFirst: false).order('name').limit(limit);
    return rows.map<Shop>(Shop.fromJson).toList();
  }

  Future<List<Shop>> featuredShops() async {
    final rows = await c
        .from('shops')
        .select()
        .eq('status', 'approved')
        .gte('featured_until', _today)
        .order('featured_until', ascending: false)
        .limit(12);
    return rows.map<Shop>(Shop.fromJson).toList();
  }

  Future<List<Shop>> nearbyShops(double lat, double lng, {double radiusKm = 15}) async {
    final res = await c.rpc('nearby_shops', params: {'p_lat': lat, 'p_lng': lng, 'p_radius_km': radiusKm, 'p_limit': 50});
    return (res as List).map((e) => Shop.fromJson(Map<String, dynamic>.from(e as Map))).toList();
  }

  Future<Shop?> shopBySlug(String slug) async {
    final row = await c.from('shops').select().eq('slug', slug).maybeSingle();
    return row == null ? null : Shop.fromJson(row);
  }

  Future<List<Product>> productsOfShop(int shopId) async {
    final rows = await c
        .from('products')
        .select()
        .eq('shop_id', shopId)
        .eq('active', true)
        .eq('blocked', false)
        .order('id');
    return rows.map<Product>(Product.fromJson).toList();
  }

  Future<List<Product>> searchProducts(String text) async {
    final t = _clean(text);
    if (t.isEmpty) return [];
    final rows = await c
        .from('products')
        .select('*, shops(name,slug)')
        .eq('active', true)
        .eq('blocked', false)
        .ilike('name', '%$t%')
        .limit(40);
    return rows.map<Product>(Product.fromJson).toList();
  }

  Future<List<StateItem>> states() async {
    final rows = await c.from('states').select().eq('active', true).order('name_en');
    return rows.map((r) => StateItem(r['code'] as String, r['name_en'] as String)).toList();
  }

  Future<List<String>> districts(String stateCode) async {
    final rows = await c.from('districts').select('name').eq('state_code', stateCode).eq('active', true).order('name');
    return rows.map<String>((r) => r['name'] as String).toList();
  }

  // ---------- customer ----------
  Future<String> placeOrder({
    required int shopId,
    required List<CartItem> items,
    required String name,
    required String phone,
    required String address,
    required String notes,
    required String fulfilment,
    required String requestId,
  }) async {
    final res = await c.rpc('place_order_v2', params: {
      'p_shop': shopId,
      'p_items': items.map((i) => {'product_id': i.product.id, 'qty': i.qty}).toList(),
      'p_name': name,
      'p_phone': phone,
      'p_address': address,
      'p_notes': notes,
      'p_fulfilment': fulfilment,
      'p_request_id': requestId,
    });
    return (res as Map)['code'] as String;
  }

  Future<List<MyOrder>> myOrders() async {
    final res = await c.rpc('my_orders');
    return (res as List).map((e) => MyOrder.fromJson(Map<String, dynamic>.from(e as Map))).toList();
  }

  Future<bool> cancelOrder(String code) async => (await c.rpc('cancel_order', params: {'p_code': code})) == true;

  Future<Profile?> myProfile(String uid) async {
    final row = await c.from('profiles').select().eq('id', uid).maybeSingle();
    return row == null ? null : Profile.fromJson(row);
  }

  Future<void> updateProfile(String name, String language) =>
      c.rpc('update_my_profile', params: {'p_name': name, 'p_language': language});

  /// 'deleted' (account gone) or 'requested' (shop with orders: admin finishes the deletion)
  Future<String> deleteAccount() async => (await c.rpc('delete_my_account')) as String;

  Future<void> registerToken(String token) =>
      c.rpc('register_device_token', params: {'p_token': token, 'p_platform': 'android'});

  // ---------- shop owner ----------
  Future<void> registerShop({
    required String name,
    required String ownerName,
    required int? categoryId,
    required String stateCode,
    required String district,
    required String town,
    required String locality,
    required String pincode,
    required String address,
    required String whatsapp,
    required String description,
    double? lat,
    double? lng,
  }) =>
      c.rpc('register_shop', params: {
        'p_name': name,
        'p_owner_name': ownerName,
        'p_category_id': categoryId,
        'p_state_code': stateCode,
        'p_district': district,
        'p_town': town,
        'p_locality': locality,
        'p_pincode': pincode,
        'p_address': address,
        'p_whatsapp': whatsapp,
        'p_description': description,
        'p_lat': lat,
        'p_lng': lng,
      });

  Future<Shop?> myShop(String uid) async {
    final row = await c.from('shops').select().eq('owner_id', uid).maybeSingle();
    return row == null ? null : Shop.fromJson(row);
  }

  Future<void> updateShop(int id, Map<String, dynamic> data) => c.from('shops').update(data).eq('id', id);

  Future<List<ShopOrder>> ownerOrders(int shopId) async {
    final rows = await c
        .from('orders')
        .select('*, order_items(*)')
        .eq('shop_id', shopId)
        .order('created_at', ascending: false)
        .limit(200);
    return rows.map<ShopOrder>(ShopOrder.fromJson).toList();
  }

  Future<void> updateOrderStatus(int orderId, String status) =>
      c.from('orders').update({'status': status}).eq('id', orderId);

  Future<List<Product>> ownerProducts(int shopId) async {
    final rows = await c.from('products').select().eq('shop_id', shopId).order('id', ascending: false);
    return rows.map<Product>(Product.fromJson).toList();
  }

  Future<void> saveProduct(Map<String, dynamic> data, {int? id}) async {
    if (id == null) {
      await c.from('products').insert(data);
    } else {
      await c.from('products').update(data).eq('id', id);
    }
  }

  Future<void> deleteProduct(int id) => c.from('products').delete().eq('id', id);

  Future<void> setInStock(int id, bool value) => c.from('products').update({'in_stock': value}).eq('id', id);

  /// Upload to the "images" bucket; the first folder MUST be the user's id (storage policy).
  Future<String> uploadImage(String uid, Uint8List bytes, String ext) async {
    final e = ext.toLowerCase();
    final mime = e == 'png' ? 'image/png' : e == 'webp' ? 'image/webp' : 'image/jpeg';
    if (bytes.length > 2 * 1024 * 1024) throw Exception('Photo is larger than 2 MB.');
    final path = '$uid/${DateTime.now().millisecondsSinceEpoch}.${e == 'jpeg' ? 'jpg' : e}';
    await c.storage.from('images').uploadBinary(path, bytes, fileOptions: FileOptions(contentType: mime, cacheControl: '31536000'));
    return c.storage.from('images').getPublicUrl(path);
  }

  RealtimeChannel watchOrders(int shopId, void Function() onChange) {
    return c
        .channel('orders-$shopId')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'orders',
          filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'shop_id', value: shopId),
          callback: (_) => onChange(),
        )
        .subscribe();
  }

  Future<void> stopWatching(RealtimeChannel ch) => c.removeChannel(ch);
}
