class Category {
  Category({required this.id, required this.slug, required this.icon, required this.names});
  final int id;
  final String slug;
  final String icon;
  final Map<String, String> names;

  String name(String lang) => names[lang] ?? names['en'] ?? slug;

  factory Category.fromJson(Map<String, dynamic> j) {
    final names = <String, String>{};
    final i18n = j['name_i18n'];
    if (i18n is Map) {
      i18n.forEach((k, v) {
        if (v is String && v.isNotEmpty) names[k.toString()] = v;
      });
    }
    names.putIfAbsent('en', () => (j['name_en'] as String?) ?? '');
    final ml = j['name_ml'] as String?;
    if (ml != null && ml.isNotEmpty) names.putIfAbsent('ml', () => ml);
    return Category(
      id: j['id'] as int,
      slug: (j['slug'] as String?) ?? '',
      icon: (j['icon'] as String?) ?? '🛍️',
      names: names,
    );
  }
}

class Shop {
  Shop({
    required this.id,
    required this.name,
    required this.slug,
    this.logo,
    this.categoryId,
    this.description = '',
    this.address = '',
    this.locality = '',
    this.town = '',
    this.district = '',
    this.pincode = '',
    this.stateCode,
    this.whatsapp = '',
    this.status = 'approved',
    this.statusNote = '',
    this.acceptingOrders = true,
    this.deliveryAvailable = false,
    this.pickupAvailable = true,
    this.deliveryFee = 0,
    this.minOrder = 0,
    this.estDelivery = '',
    this.upiId = '',
    this.lat,
    this.lng,
    this.featuredUntil,
    this.distanceKm,
  });

  final int id;
  final String name;
  final String slug;
  final String? logo;
  final int? categoryId;
  final String description;
  final String address;
  final String locality;
  final String town;
  final String district;
  final String pincode;
  final String? stateCode;
  final String whatsapp;
  final String status;
  final String statusNote;
  final bool acceptingOrders;
  final bool deliveryAvailable;
  final bool pickupAvailable;
  final int deliveryFee;
  final int minOrder;
  final String estDelivery;
  final String upiId;
  final double? lat;
  final double? lng;
  final String? featuredUntil;
  final double? distanceKm;

  factory Shop.fromJson(Map<String, dynamic> j) => Shop(
        id: j['id'] as int,
        name: (j['name'] as String?) ?? '',
        slug: (j['slug'] as String?) ?? '',
        logo: j['logo'] as String?,
        categoryId: (j['category_id'] as num?)?.toInt(),
        description: (j['description'] as String?) ?? '',
        address: (j['address'] as String?) ?? '',
        locality: (j['locality'] as String?) ?? '',
        town: (j['town'] as String?) ?? '',
        district: (j['district'] as String?) ?? '',
        pincode: (j['pincode'] as String?) ?? '',
        stateCode: j['state_code'] as String?,
        whatsapp: (j['whatsapp'] as String?) ?? '',
        status: (j['status'] as String?) ?? 'approved',
        statusNote: (j['status_note'] as String?) ?? '',
        acceptingOrders: (j['accepting_orders'] as bool?) ?? true,
        deliveryAvailable: (j['delivery_available'] as bool?) ?? false,
        pickupAvailable: (j['pickup_available'] as bool?) ?? true,
        deliveryFee: (j['delivery_fee'] as num?)?.toInt() ?? 0,
        minOrder: (j['min_order'] as num?)?.toInt() ?? 0,
        estDelivery: (j['est_delivery'] as String?) ?? '',
        upiId: (j['upi_id'] as String?) ?? '',
        lat: (j['lat'] as num?)?.toDouble(),
        lng: (j['lng'] as num?)?.toDouble(),
        featuredUntil: j['featured_until'] as String?,
        distanceKm: (j['distance_km'] as num?)?.toDouble(),
      );

  String get place => [if (locality.isNotEmpty) locality, town].where((s) => s.isNotEmpty).join(', ');
}

class Product {
  Product({
    required this.id,
    required this.shopId,
    required this.name,
    this.description = '',
    this.categoryId,
    required this.price,
    this.discountPrice,
    this.unit = '',
    this.inStock = true,
    this.stockQty,
    this.images = const [],
    this.active = true,
    this.shopName,
    this.shopSlug,
  });

  final int id;
  final int shopId;
  final String name;
  final String description;
  final int? categoryId;
  final int price;
  final int? discountPrice;
  final String unit;
  final bool inStock;
  final int? stockQty;
  final List<String> images;
  final bool active;
  final String? shopName;
  final String? shopSlug;

  int get effectivePrice => discountPrice ?? price;
  bool get available => inStock && (stockQty == null || stockQty! > 0);

  factory Product.fromJson(Map<String, dynamic> j) {
    final shop = j['shops'];
    return Product(
      id: j['id'] as int,
      shopId: j['shop_id'] as int,
      name: (j['name'] as String?) ?? '',
      description: (j['description'] as String?) ?? '',
      categoryId: (j['category_id'] as num?)?.toInt(),
      price: (j['price'] as num).toInt(),
      discountPrice: (j['discount_price'] as num?)?.toInt(),
      unit: (j['unit'] as String?) ?? '',
      inStock: (j['in_stock'] as bool?) ?? true,
      stockQty: (j['stock_qty'] as num?)?.toInt(),
      images: [j['image'], j['image2'], j['image3']].whereType<String>().where((s) => s.isNotEmpty).toList(),
      active: (j['active'] as bool?) ?? true,
      shopName: shop is Map ? shop['name'] as String? : null,
      shopSlug: shop is Map ? shop['slug'] as String? : null,
    );
  }
}

class CartItem {
  CartItem(this.product, this.qty);
  final Product product;
  int qty;
}

class OrderLine {
  OrderLine({required this.name, required this.unitPrice, required this.qty});
  final String name;
  final int unitPrice;
  final int qty;
  factory OrderLine.fromJson(Map<String, dynamic> j) => OrderLine(
        name: (j['name'] as String?) ?? '',
        unitPrice: (j['unit_price'] as num).toInt(),
        qty: (j['qty'] as num).toInt(),
      );
}

/// An order as the customer sees it (from my_orders()).
class MyOrder {
  MyOrder({
    required this.code,
    required this.status,
    required this.fulfilment,
    required this.total,
    required this.createdAt,
    required this.items,
    required this.shopName,
    required this.shopWhatsapp,
    required this.shopSlug,
  });
  final String code;
  final String status;
  final String fulfilment;
  final int total;
  final DateTime createdAt;
  final List<OrderLine> items;
  final String shopName;
  final String shopWhatsapp;
  final String shopSlug;

  factory MyOrder.fromJson(Map<String, dynamic> j) {
    final shop = Map<String, dynamic>.from(j['shop'] as Map);
    return MyOrder(
      code: j['code'] as String,
      status: j['status'] as String,
      fulfilment: j['fulfilment'] as String,
      total: (j['total'] as num).toInt(),
      createdAt: DateTime.parse(j['created_at'] as String),
      items: (j['items'] as List).map((e) => OrderLine.fromJson(Map<String, dynamic>.from(e as Map))).toList(),
      shopName: (shop['name'] as String?) ?? '',
      shopWhatsapp: (shop['whatsapp'] as String?) ?? '',
      shopSlug: (shop['slug'] as String?) ?? '',
    );
  }
}

/// An order as the shop owner sees it.
class ShopOrder {
  ShopOrder({
    required this.id,
    required this.code,
    required this.customerName,
    required this.customerPhone,
    required this.address,
    required this.notes,
    required this.fulfilment,
    required this.total,
    required this.status,
    required this.channel,
    required this.createdAt,
    required this.items,
  });
  final int id;
  final String code;
  final String customerName;
  final String customerPhone;
  final String address;
  final String notes;
  final String fulfilment;
  final int total;
  final String status;
  final String channel;
  final DateTime createdAt;
  final List<OrderLine> items;

  factory ShopOrder.fromJson(Map<String, dynamic> j) => ShopOrder(
        id: j['id'] as int,
        code: j['code'] as String,
        customerName: (j['customer_name'] as String?) ?? '',
        customerPhone: (j['customer_phone'] as String?) ?? '',
        address: (j['address'] as String?) ?? '',
        notes: (j['notes'] as String?) ?? '',
        fulfilment: j['fulfilment'] as String,
        total: (j['total'] as num).toInt(),
        status: j['status'] as String,
        channel: (j['channel'] as String?) ?? 'web',
        createdAt: DateTime.parse(j['created_at'] as String),
        items: ((j['order_items'] as List?) ?? const [])
            .map((e) => OrderLine.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList(),
      );
}

class Profile {
  Profile({required this.id, required this.role, required this.fullName, required this.phone, required this.language});
  final String id;
  final String role;
  final String fullName;
  final String phone;
  final String language;
  factory Profile.fromJson(Map<String, dynamic> j) => Profile(
        id: j['id'] as String,
        role: (j['role'] as String?) ?? 'customer',
        fullName: (j['full_name'] as String?) ?? '',
        phone: (j['phone'] as String?) ?? '',
        language: (j['preferred_language'] as String?) ?? 'en',
      );
}

class StateItem {
  StateItem(this.code, this.name);
  final String code;
  final String name;
}

class LatLng {
  const LatLng(this.lat, this.lng);
  final double lat;
  final double lng;
}
