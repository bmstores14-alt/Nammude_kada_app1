import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/providers.dart';
import '../../core/theme.dart';
import '../../core/util.dart';
import '../../data/models.dart';
import '../../l10n/app_localizations.dart';
import '../../widgets/common.dart';
import '../auth/login_screen.dart';

class OrdersScreen extends ConsumerWidget {
  const OrdersScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = AppLocalizations.of(context);
    final loggedIn = ref.watch(userIdProvider) != null;
    return Scaffold(
      appBar: AppBar(title: Text(l.orders)),
      body: !loggedIn
          ? const LoginPrompt()
          : AsyncView<List<MyOrder>>(
              value: ref.watch(myOrdersProvider),
              onRetry: () => ref.invalidate(myOrdersProvider),
              builder: (orders) => RefreshIndicator(
                onRefresh: () async {
                  ref.invalidate(myOrdersProvider);
                  await ref.read(myOrdersProvider.future).catchError((_) => <MyOrder>[]);
                },
                child: orders.isEmpty
                    ? ListView(children: [
                        SizedBox(height: 300, child: EmptyState(icon: Icons.receipt_long_outlined, text: l.noOrdersYet)),
                      ])
                    : ListView(padding: const EdgeInsets.all(12), children: [
                        for (final o in orders) _OrderCard(order: o),
                      ]),
              ),
            ),
    );
  }
}

class _OrderCard extends ConsumerWidget {
  const _OrderCard({required this.order});
  final MyOrder order;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = AppLocalizations.of(context);
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      padding: const EdgeInsets.all(14),
      decoration: cardBox(),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(child: Text(order.shopName, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800))),
          StatusChip(order.status),
        ]),
        const SizedBox(height: 2),
        Text('${l.orderCodeLabel(order.code)} · ${fmtDate(order.createdAt)}',
            style: const TextStyle(color: Colors.black54, fontSize: 12)),
        const SizedBox(height: 8),
        for (final i in order.items)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 1),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Expanded(child: Text('${i.qty} × ${i.name}', maxLines: 1, overflow: TextOverflow.ellipsis)),
              Text(inr(i.unitPrice * i.qty)),
            ]),
          ),
        const Divider(),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(order.fulfilment == 'delivery' ? l.delivery : l.pickup, style: const TextStyle(color: Colors.black54)),
          Text(inr(order.total), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
        ]),
        const SizedBox(height: 8),
        Row(children: [
          if (order.shopWhatsapp.isNotEmpty) ...[
            OutlinedButton.icon(
              onPressed: () => callNumber(order.shopWhatsapp),
              icon: const Icon(Icons.call, size: 16),
              label: Text(l.callAction),
            ),
            const SizedBox(width: 8),
            OutlinedButton.icon(
              onPressed: () => openWhatsApp(order.shopWhatsapp, order.code),
              icon: const Icon(Icons.chat, size: 16),
              label: Text(l.whatsapp),
            ),
          ],
          const Spacer(),
          if (order.status == 'new')
            TextButton(
              style: TextButton.styleFrom(foregroundColor: const Color(0xFFB3261E)),
              onPressed: () async {
                if (!await confirmDialog(context, l.cancelOrder)) return;
                try {
                  await ref.read(repoProvider).cancelOrder(order.code);
                  ref.invalidate(myOrdersProvider);
                } catch (e) {
                  if (context.mounted) snack(context, errText(e));
                }
              },
              child: Text(l.cancelOrder),
            ),
        ]),
      ]),
    );
  }
}
