import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/config.dart';
import '../../core/providers.dart';
import '../../core/theme.dart';
import '../../core/util.dart';
import '../../l10n/app_localizations.dart';
import '../../widgets/common.dart';

class AccountScreen extends ConsumerWidget {
  const AccountScreen({super.key});

  Future<void> _delete(BuildContext context, WidgetRef ref) async {
    final l = AppLocalizations.of(context);
    if (!await confirmDialog(context, l.deleteAccountWarning, okLabel: l.deleteAccount)) return;
    try {
      final result = await ref.read(repoProvider).deleteAccount();
      if (result == 'requested') {
        if (context.mounted) snack(context, l.deletionRequested);
        ref.invalidate(myShopProvider);
        return;
      }
      await ref.read(clientProvider).auth.signOut();
      ref.read(cartProvider.notifier).clear();
      ref.read(tabProvider.notifier).state = 0;
    } catch (e) {
      if (context.mounted) snack(context, errText(e));
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = AppLocalizations.of(context);
    final loggedIn = ref.watch(userIdProvider) != null;
    final profile = ref.watch(profileProvider).valueOrNull;
    final lang = ref.watch(localeProvider).languageCode;
    final user = ref.watch(clientProvider).auth.currentUser;

    return Scaffold(
      appBar: AppBar(title: Text(l.account)),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        if (loggedIn)
          Container(
            padding: const EdgeInsets.all(16),
            decoration: cardBox(),
            child: Row(children: [
              const CircleAvatar(radius: 26, backgroundColor: Brand.green, child: Icon(Icons.person, color: Colors.white)),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(
                    (profile?.fullName.isNotEmpty ?? false) ? profile!.fullName : (user?.email ?? user?.phone ?? ''),
                    style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
                  ),
                  if ((profile?.phone ?? '').isNotEmpty) Text('+91 ${profile!.phone}', style: const TextStyle(color: Colors.black54)),
                ]),
              ),
            ]),
          )
        else
          FilledButton(onPressed: () => context.push('/login'), child: Text(l.login)),
        const SizedBox(height: 12),
        // Opening a shop is free: always visible, one tap.
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Brand.yellow.withValues(alpha: 0.25),
            borderRadius: BorderRadius.circular(14),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(profile?.role == 'owner' ? l.myShop : l.openFreeShop,
                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            Text(l.freeShopNote),
            const SizedBox(height: 10),
            FilledButton(
              onPressed: () => context.push(loggedIn ? '/owner' : '/login'),
              child: Text(profile?.role == 'owner' ? l.myShop : l.openFreeShop),
            ),
          ]),
        ),
        const SizedBox(height: 12),
        ListTile(
          leading: const Icon(Icons.language),
          title: Text(l.language),
          subtitle: Text(AppConfig.languages[lang] ?? lang),
          onTap: () => showLanguageSheet(context, ref),
        ),
        ListTile(
          leading: const Icon(Icons.privacy_tip_outlined),
          title: Text(l.privacyPolicy),
          onTap: () => openUrl(AppConfig.privacyUrl),
        ),
        ListTile(
          leading: const Icon(Icons.description_outlined),
          title: Text(l.termsConditions),
          onTap: () => openUrl(AppConfig.termsUrl),
        ),
        if (loggedIn) ...[
          ListTile(
            leading: const Icon(Icons.logout),
            title: Text(l.logout),
            onTap: () async {
              await ref.read(clientProvider).auth.signOut();
              ref.read(cartProvider.notifier).clear();
              ref.invalidate(profileProvider);
              ref.invalidate(myShopProvider);
            },
          ),
          ListTile(
            leading: const Icon(Icons.delete_forever, color: Color(0xFFB3261E)),
            title: Text(l.deleteAccount, style: const TextStyle(color: Color(0xFFB3261E))),
            onTap: () => _delete(context, ref),
          ),
        ],
      ]),
    );
  }
}
