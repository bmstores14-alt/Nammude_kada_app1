import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/providers.dart';
import '../../core/theme.dart';
import '../../core/util.dart';
import '../../l10n/app_localizations.dart';
import '../../widgets/common.dart';

class CartScreen extends ConsumerWidget {
  const CartScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = AppLocalizations.of(context);
    final cart = ref.watch(cartProvider);
    final shop = cart.shop;
    return Scaffold(
      appBar: AppBar(title: Text(l.cart)),
      body: cart.count == 0 || shop == null
          ? EmptyState(icon: Icons.shopping_cart_outlined, text: l.emptyCart)
          : ListView(padding: const EdgeInsets.all(16), children: [
              Text(shop.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              for (final item in cart.items.values)
                Container(
                  margin: const EdgeInsets.symmetric(vertical: 5),
                  padding: const EdgeInsets.all(10),
                  decoration: cardBox(),
                  child: Row(children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: NetImage(item.product.images.isEmpty ? null : item.product.images.first,
                          size: 56, fallback: Icons.shopping_bag),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(item.product.name, maxLines: 2, overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w700)),
                        Text(inr(item.product.effectivePrice), style: const TextStyle(color: Brand.green)),
                      ]),
                    ),
                    IconButton(
                        onPressed: () => ref.read(cartProvider.notifier).setQty(item.product.id, item.qty - 1),
                        icon: const Icon(Icons.remove_circle_outline)),
                    Text('${item.qty}', style: const TextStyle(fontWeight: FontWeight.w800)),
                    IconButton(
                        onPressed: () => ref.read(cartProvider.notifier).setQty(item.product.id, item.qty + 1),
                        icon: const Icon(Icons.add_circle, color: Brand.green)),
                  ]),
                ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: cardBox(),
                child: Column(children: [
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    Text(l.total, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                    Text(inr(cart.subtotal), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
                  ]),
                  if (shop.minOrder > cart.subtotal)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text('${l.minOrder.replaceAll(' (₹)', '')}: ${inr(shop.minOrder)}',
                          style: const TextStyle(color: Color(0xFFB3261E))),
                    ),
                ]),
              ),
              const SizedBox(height: 16),
              FilledButton(
                onPressed: shop.minOrder > cart.subtotal ? null : () => context.push('/checkout'),
                child: Text(l.checkout),
              ),
            ]),
    );
  }
}
