import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:uuid/uuid.dart';

import '../../core/providers.dart';
import '../../core/theme.dart';
import '../../core/util.dart';
import '../../l10n/app_localizations.dart';
import '../../widgets/common.dart';
import '../auth/login_screen.dart';

class CheckoutScreen extends ConsumerStatefulWidget {
  const CheckoutScreen({super.key});
  @override
  ConsumerState<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends ConsumerState<CheckoutScreen> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _address = TextEditingController();
  final _notes = TextEditingController();
  // One id per checkout attempt: if the network drops and the customer taps again,
  // the server returns the first order instead of creating a duplicate.
  final String _requestId = const Uuid().v4();
  String _fulfilment = 'pickup';
  bool _busy = false;
  bool _phoneFromLogin = false;
  bool _prefilled = false;

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _address.dispose();
    _notes.dispose();
    super.dispose();
  }

  void _prefill() {
    if (_prefilled) return;
    final user = ref.read(clientProvider).auth.currentUser;
    if (user == null) return;
    _prefilled = true;
    final loginPhone = normalizeMobile(user.phone);
    if (loginPhone != null) {
      _phone.text = loginPhone;
      _phoneFromLogin = true;
    }
    final shop = ref.read(cartProvider).shop;
    if (shop != null) _fulfilment = shop.deliveryAvailable && !shop.pickupAvailable ? 'delivery' : 'pickup';
    ref.read(profileProvider.future).then((p) {
      if (mounted && p != null && _name.text.isEmpty) setState(() => _name.text = p.fullName);
    });
  }

  Future<void> _place() async {
    final l = AppLocalizations.of(context);
    if (!_form.currentState!.validate()) return;
    final cart = ref.read(cartProvider);
    final shop = cart.shop;
    if (shop == null || cart.count == 0) return;
    setState(() => _busy = true);
    try {
      final code = await ref.read(repoProvider).placeOrder(
            shopId: shop.id,
            items: cart.items.values.toList(),
            name: _name.text.trim(),
            phone: normalizeMobile(_phone.text) ?? _phone.text.trim(),
            address: _fulfilment == 'delivery' ? _address.text.trim() : '',
            notes: _notes.text.trim(),
            fulfilment: _fulfilment,
            requestId: _requestId,
          );
      ref.read(cartProvider.notifier).clear();
      ref.invalidate(myOrdersProvider);
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (c) => AlertDialog(
          icon: const Icon(Icons.check_circle, color: Brand.green, size: 48),
          title: Text(l.orderPlaced),
          content: Text(l.orderCodeLabel(code), textAlign: TextAlign.center),
          actions: [TextButton(onPressed: () => Navigator.pop(c), child: Text(l.orders))],
        ),
      );
      ref.read(tabProvider.notifier).state = 2;
      if (mounted) context.go('/');
    } catch (e) {
      if (mounted) snack(context, errText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    final loggedIn = ref.watch(userIdProvider) != null;
    final cart = ref.watch(cartProvider);
    final shop = cart.shop;
    if (loggedIn) _prefill();

    return Scaffold(
      appBar: AppBar(title: Text(l.checkout)),
      body: !loggedIn
          ? const LoginPrompt()
          : (shop == null || cart.count == 0)
              ? EmptyState(icon: Icons.shopping_cart_outlined, text: l.emptyCart)
              : Form(
                  key: _form,
                  child: ListView(padding: const EdgeInsets.all(16), children: [
                    Text(shop.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 12),
                    if (shop.deliveryAvailable && shop.pickupAvailable)
                      SegmentedButton<String>(
                        segments: [
                          ButtonSegment(value: 'pickup', label: Text(l.pickup), icon: const Icon(Icons.storefront)),
                          ButtonSegment(value: 'delivery', label: Text(l.delivery), icon: const Icon(Icons.delivery_dining)),
                        ],
                        selected: {_fulfilment},
                        onSelectionChanged: (s) => setState(() => _fulfilment = s.first),
                      )
                    else
                      Text(shop.deliveryAvailable ? l.delivery : l.pickup,
                          style: const TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _name,
                      decoration: deco(l.yourName),
                      validator: (v) => (v == null || v.trim().length < 2) ? l.requiredField : null,
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _phone,
                      enabled: !_phoneFromLogin,
                      keyboardType: TextInputType.phone,
                      decoration: deco(l.mobileNumber).copyWith(prefixText: '+91 '),
                      validator: (v) => normalizeMobile(v) == null ? l.invalidMobile : null,
                    ),
                    if (_fulfilment == 'delivery') ...[
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _address,
                        maxLines: 3,
                        decoration: deco(l.address),
                        validator: (v) => (v == null || v.trim().length < 8) ? l.requiredField : null,
                      ),
                    ],
                    const SizedBox(height: 12),
                    TextFormField(controller: _notes, maxLines: 2, decoration: deco(l.notes)),
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: cardBox(),
                      child: Column(children: [
                        _row(l.subtotal, inr(cart.subtotal)),
                        if (_fulfilment == 'delivery' && shop.deliveryFee > 0) _row(l.deliveryFee, inr(shop.deliveryFee)),
                        const Divider(),
                        _row(
                          l.total,
                          inr(cart.subtotal + (_fulfilment == 'delivery' ? shop.deliveryFee : 0)),
                          bold: true,
                        ),
                      ]),
                    ),
                    const SizedBox(height: 8),
                    Text(l.payShopDirectly, style: const TextStyle(color: Colors.black54, fontSize: 13)),
                    const SizedBox(height: 16),
                    FilledButton(onPressed: _busy ? null : _place, child: Text(l.placeOrder)),
                    if (_busy) const Padding(padding: EdgeInsets.only(top: 12), child: LinearProgressIndicator()),
                  ]),
                ),
    );
  }

  Widget _row(String a, String b, {bool bold = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(a, style: TextStyle(fontWeight: bold ? FontWeight.w800 : FontWeight.w500)),
          Text(b, style: TextStyle(fontWeight: bold ? FontWeight.w800 : FontWeight.w600, fontSize: bold ? 18 : 15)),
        ]),
      );
}
