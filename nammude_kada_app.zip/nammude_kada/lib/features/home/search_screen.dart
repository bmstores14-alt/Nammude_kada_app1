import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/providers.dart';
import '../../core/theme.dart';
import '../../core/util.dart';
import '../../l10n/app_localizations.dart';
import '../../widgets/common.dart';
import '../../widgets/shop_card.dart';

/// Searches shops (name, town, district, PIN code) and products at the same time.
class SearchScreen extends ConsumerStatefulWidget {
  const SearchScreen({super.key, required this.initial});
  final String initial;
  @override
  ConsumerState<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends ConsumerState<SearchScreen> {
  late final TextEditingController _c = TextEditingController(text: widget.initial);
  late String _text = widget.initial;

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    final shops = ref.watch(shopsProvider(ShopQuery(text: _text)));
    final products = ref.watch(productSearchProvider(_text));
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _c,
          autofocus: widget.initial.isEmpty,
          style: const TextStyle(color: Colors.white),
          cursorColor: Colors.white,
          textInputAction: TextInputAction.search,
          onSubmitted: (v) => setState(() => _text = v.trim()),
          decoration: InputDecoration(
            hintText: l.searchHint,
            hintStyle: const TextStyle(color: Colors.white60),
            border: InputBorder.none,
          ),
        ),
      ),
      body: ListView(children: [
        SectionTitle(l.shops),
        AsyncView(
          value: shops,
          onRetry: () => ref.invalidate(shopsProvider),
          builder: (items) => items.isEmpty
              ? Padding(padding: const EdgeInsets.all(16), child: Text(l.noShopsFound))
              : Column(children: [for (final s in items) ShopCard(shop: s)]),
        ),
        SectionTitle(l.products),
        AsyncView(
          value: products,
          onRetry: () => ref.invalidate(productSearchProvider),
          builder: (items) => items.isEmpty
              ? Padding(padding: const EdgeInsets.all(16), child: Text(l.noShopsFound))
              : Column(children: [
                  for (final p in items)
                    InkWell(
                      onTap: p.shopSlug == null ? null : () => context.push('/shop/${Uri.encodeComponent(p.shopSlug!)}'),
                      child: Container(
                        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                        padding: const EdgeInsets.all(10),
                        decoration: cardBox(),
                        child: Row(children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: NetImage(p.images.isEmpty ? null : p.images.first, size: 56, fallback: Icons.shopping_bag),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(p.name, maxLines: 1, overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontWeight: FontWeight.w700)),
                              if (p.shopName != null)
                                Text(p.shopName!, style: const TextStyle(color: Colors.black54, fontSize: 12)),
                            ]),
                          ),
                          Text(inr(p.effectivePrice), style: const TextStyle(fontWeight: FontWeight.w800, color: Brand.green)),
                        ]),
                      ),
                    ),
                ]),
        ),
        const SizedBox(height: 24),
      ]),
    );
  }
}
