import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/providers.dart';
import '../../l10n/app_localizations.dart';
import '../../services/push_service.dart';
import '../account/account_screen.dart';
import '../cart/cart_screen.dart';
import '../orders/orders_screen.dart';
import 'home_screen.dart';

class RootScreen extends ConsumerWidget {
  const RootScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = AppLocalizations.of(context);
    final tab = ref.watch(tabProvider);
    final cartCount = ref.watch(cartProvider.select((c) => c.count));

    // register this phone for order notifications whenever someone logs in
    ref.listen(sessionProvider, (prev, next) {
      if (next.valueOrNull != null) PushService.register(ref.read(repoProvider));
    });
    // always show fresh orders when the Orders tab is opened
    ref.listen<int>(tabProvider, (prev, next) {
      if (next == 2) ref.invalidate(myOrdersProvider);
    });

    return Scaffold(
      body: IndexedStack(
        index: tab,
        children: const [HomeScreen(), CartScreen(), OrdersScreen(), AccountScreen()],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => ref.read(tabProvider.notifier).state = i,
        destinations: [
          NavigationDestination(
              icon: const Icon(Icons.storefront_outlined), selectedIcon: const Icon(Icons.storefront), label: l.home),
          NavigationDestination(
            icon: Badge(
                isLabelVisible: cartCount > 0,
                label: Text('$cartCount'),
                child: const Icon(Icons.shopping_cart_outlined)),
            selectedIcon: const Icon(Icons.shopping_cart),
            label: l.cart,
          ),
          NavigationDestination(
              icon: const Icon(Icons.receipt_long_outlined), selectedIcon: const Icon(Icons.receipt_long), label: l.orders),
          NavigationDestination(
              icon: const Icon(Icons.person_outline), selectedIcon: const Icon(Icons.person), label: l.account),
        ],
      ),
    );
  }
}
