import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/providers.dart';
import '../../l10n/app_localizations.dart';
import '../../widgets/common.dart';
import '../../widgets/shop_card.dart';

class ShopsScreen extends ConsumerWidget {
  const ShopsScreen({super.key, required this.title, required this.query});
  final String title;
  final ShopQuery query;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = AppLocalizations.of(context);
    final shops = ref.watch(shopsProvider(query));
    return Scaffold(
      appBar: AppBar(title: Text(title.isEmpty ? l.shops : title)),
      body: AsyncView(
        value: shops,
        onRetry: () => ref.invalidate(shopsProvider(query)),
        builder: (items) => items.isEmpty
            ? EmptyState(icon: Icons.storefront_outlined, text: l.noShopsFound)
            : ListView(padding: const EdgeInsets.symmetric(vertical: 8), children: [
                for (final s in items) ShopCard(shop: s),
              ]),
      ),
    );
  }
}
