import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:geolocator/geolocator.dart';
import 'package:go_router/go_router.dart';

import '../../core/config.dart';
import '../../core/providers.dart';
import '../../core/theme.dart';
import '../../core/util.dart';
import '../../data/models.dart';
import '../../l10n/app_localizations.dart';
import '../../widgets/common.dart';
import '../../widgets/shop_card.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});
  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  final _q = TextEditingController();
  bool _locating = false;

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  Future<void> _useLocation() async {
    final l = AppLocalizations.of(context);
    setState(() => _locating = true);
    try {
      var perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
      if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
        throw Exception(l.somethingWrong);
      }
      final pos = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(accuracy: LocationAccuracy.low),
      );
      ref.read(locationProvider.notifier).state = LatLng(pos.latitude, pos.longitude);
    } catch (e) {
      if (mounted) snack(context, errText(e));
    } finally {
      if (mounted) setState(() => _locating = false);
    }
  }

  void _search() {
    final t = _q.text.trim();
    if (t.isEmpty) return;
    context.push('/search?q=${Uri.encodeQueryComponent(t)}');
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    final lang = ref.watch(localeProvider).languageCode;
    final cats = ref.watch(categoriesProvider);
    final loc = ref.watch(locationProvider);
    final featured = ref.watch(featuredShopsProvider);
    final list = ref.watch(shopsProvider(ShopQuery(lat: loc?.lat, lng: loc?.lng)));

    return RefreshIndicator(
      onRefresh: () async {
        ref.invalidate(categoriesProvider);
        ref.invalidate(featuredShopsProvider);
        ref.invalidate(shopsProvider);
        await ref.read(featuredShopsProvider.future).catchError((_) => <Shop>[]);
      },
      child: ListView(padding: EdgeInsets.zero, children: [
        Container(
          color: Brand.green,
          padding: EdgeInsets.fromLTRB(16, MediaQuery.of(context).padding.top + 12, 16, 16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Text('Nammude Kada', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w800)),
              const Spacer(),
              IconButton(
                icon: const Icon(Icons.language, color: Colors.white),
                onPressed: () => showLanguageSheet(context, ref),
              ),
            ]),
            const Text(AppConfig.tagline, style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 14),
            TextField(
              controller: _q,
              textInputAction: TextInputAction.search,
              onSubmitted: (_) => _search(),
              decoration: deco(l.searchHint).copyWith(
                prefixIcon: const Icon(Icons.search),
                suffixIcon: IconButton(icon: const Icon(Icons.arrow_forward), onPressed: _search),
              ),
            ),
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton.icon(
                style: TextButton.styleFrom(foregroundColor: Brand.yellow),
                onPressed: _locating ? null : _useLocation,
                icon: _locating
                    ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.my_location, size: 18),
                label: Text(l.useMyLocation),
              ),
            ),
          ]),
        ),
        SectionTitle(l.categories),
        SizedBox(
          height: 96,
          child: cats.when(
            data: (items) => ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: [
                for (final c in items)
                  InkWell(
                    borderRadius: BorderRadius.circular(14),
                    onTap: () => context.push('/shops?cat=${c.id}&title=${Uri.encodeQueryComponent(c.name(lang))}'),
                    child: Container(
                      width: 84,
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      padding: const EdgeInsets.all(8),
                      decoration: cardBox(),
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Text(c.icon, style: const TextStyle(fontSize: 28)),
                        const SizedBox(height: 4),
                        Text(c.name(lang),
                            maxLines: 2,
                            textAlign: TextAlign.center,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600)),
                      ]),
                    ),
                  ),
              ],
            ),
            loading: () => const Loading(),
            error: (e, _) => ErrorRetry(error: e, onRetry: () => ref.invalidate(categoriesProvider)),
          ),
        ),
        featured.maybeWhen(
          data: (items) => items.isEmpty
              ? const SizedBox.shrink()
              : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  SectionTitle(l.featuredShops),
                  for (final s in items) ShopCard(shop: s),
                ]),
          orElse: () => const SizedBox.shrink(),
        ),
        SectionTitle(loc != null ? l.nearbyShops : l.allShops),
        list.when(
          data: (items) => items.isEmpty
              ? Padding(padding: const EdgeInsets.all(24), child: Center(child: Text(l.noShopsFound)))
              : Column(children: [for (final s in items) ShopCard(shop: s)]),
          loading: () => const Loading(),
          error: (e, _) => ErrorRetry(error: e, onRetry: () => ref.invalidate(shopsProvider)),
        ),
        const SizedBox(height: 24),
      ]),
    );
  }
}
