import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/providers.dart';
import '../../core/theme.dart';
import '../../core/util.dart';
import '../../data/models.dart';
import '../../l10n/app_localizations.dart';
import '../../widgets/common.dart';

class ShopScreen extends ConsumerWidget {
  const ShopScreen({super.key, required this.slug});
  final String slug;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = AppLocalizations.of(context);
    final shopAsync = ref.watch(shopBySlugProvider(slug));
    return Scaffold(
      appBar: AppBar(title: Text(shopAsync.valueOrNull?.name ?? '')),
      body: AsyncView<Shop?>(
        value: shopAsync,
        onRetry: () => ref.invalidate(shopBySlugProvider(slug)),
        builder: (shop) {
          if (shop == null) return EmptyState(icon: Icons.storefront_outlined, text: l.noShopsFound);
          return _ShopBody(shop: shop);
        },
      ),
      bottomNavigationBar: _CartBar(slug: slug),
    );
  }
}

class _CartBar extends ConsumerWidget {
  const _CartBar({required this.slug});
  final String slug;
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cart = ref.watch(cartProvider);
    if (cart.count == 0 || cart.shop?.slug != slug) return const SizedBox.shrink();
    final l = AppLocalizations.of(context);
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: FilledButton(
          onPressed: () {
            ref.read(tabProvider.notifier).state = 1;
            context.go('/');
          },
          child: Text('${l.cart} · ${cart.count} · ${inr(cart.subtotal)}'),
        ),
      ),
    );
  }
}

class _ShopBody extends ConsumerWidget {
  const _ShopBody({required this.shop});
  final Shop shop;

  Future<void> _add(BuildContext context, WidgetRef ref, Product p) async {
    final l = AppLocalizations.of(context);
    final cart = ref.read(cartProvider.notifier);
    if (!cart.canAdd(shop)) {
      final ok = await confirmDialog(context, l.otherShopInCart);
      if (!ok) return;
      cart.clear();
    }
    cart.add(shop, p);
  }

  void _details(BuildContext context, WidgetRef ref, Product p) {
    final l = AppLocalizations.of(context);
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (c) => SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (p.images.isNotEmpty)
              SizedBox(
                height: 220,
                child: PageView(children: [
                  for (final u in p.images)
                    ClipRRect(borderRadius: BorderRadius.circular(12), child: NetImage(u, fit: BoxFit.cover)),
                ]),
              ),
            const SizedBox(height: 12),
            Text(p.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            if (p.unit.isNotEmpty) Text(p.unit, style: const TextStyle(color: Colors.black54)),
            const SizedBox(height: 4),
            _price(p, 20),
            if (p.description.isNotEmpty) ...[const SizedBox(height: 12), Text(p.description)],
            const SizedBox(height: 16),
            FilledButton(
              onPressed: p.available && shop.acceptingOrders
                  ? () {
                      Navigator.pop(c);
                      _add(context, ref, p);
                    }
                  : null,
              child: Text(p.available ? l.addToCart : l.outOfStock),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _price(Product p, double size) => Row(children: [
        Text(inr(p.effectivePrice), style: TextStyle(fontSize: size, fontWeight: FontWeight.w800, color: Brand.green)),
        if (p.discountPrice != null) ...[
          const SizedBox(width: 8),
          Text(inr(p.price),
              style: TextStyle(fontSize: size * 0.75, color: Colors.black45, decoration: TextDecoration.lineThrough)),
        ],
      ]);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = AppLocalizations.of(context);
    final products = ref.watch(shopProductsProvider(shop.id));
    final cart = ref.watch(cartProvider);
    return ListView(padding: const EdgeInsets.only(bottom: 24), children: [
      Container(
        margin: const EdgeInsets.all(16),
        padding: const EdgeInsets.all(14),
        decoration: cardBox(),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            ClipRRect(borderRadius: BorderRadius.circular(12), child: NetImage(shop.logo, size: 72)),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(shop.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                Text('${shop.address}${shop.pincode.isEmpty ? '' : ' · ${shop.pincode}'}',
                    style: const TextStyle(color: Colors.black54)),
              ]),
            ),
          ]),
          if (shop.description.isNotEmpty) ...[const SizedBox(height: 8), Text(shop.description)],
          const SizedBox(height: 10),
          Wrap(spacing: 8, runSpacing: 4, children: [
            if (shop.deliveryAvailable)
              Chip(label: Text('${l.delivery}${shop.deliveryFee > 0 ? ' · ${inr(shop.deliveryFee)}' : ''}')),
            if (shop.pickupAvailable) Chip(label: Text(l.pickup)),
            if (shop.minOrder > 0) Chip(label: Text('${l.minOrder.replaceAll(' (₹)', '')}: ${inr(shop.minOrder)}')),
          ]),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: shop.whatsapp.isEmpty ? null : () => callNumber(shop.whatsapp),
                icon: const Icon(Icons.call, size: 18),
                label: Text(l.callAction),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: shop.whatsapp.isEmpty ? null : () => openWhatsApp(shop.whatsapp),
                icon: const Icon(Icons.chat, size: 18),
                label: Text(l.whatsapp),
              ),
            ),
          ]),
        ]),
      ),
      SectionTitle(l.products),
      AsyncView(
        value: products,
        onRetry: () => ref.invalidate(shopProductsProvider(shop.id)),
        builder: (items) => items.isEmpty
            ? Padding(padding: const EdgeInsets.all(24), child: Center(child: Text(l.noShopsFound)))
            : Column(children: [
                for (final p in items)
                  InkWell(
                    onTap: () => _details(context, ref, p),
                    child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                      padding: const EdgeInsets.all(10),
                      decoration: cardBox(),
                      child: Row(children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: NetImage(p.images.isEmpty ? null : p.images.first, size: 72, fallback: Icons.shopping_bag),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(p.name, maxLines: 2, overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                            if (p.unit.isNotEmpty) Text(p.unit, style: const TextStyle(color: Colors.black54, fontSize: 12)),
                            const SizedBox(height: 2),
                            _price(p, 16),
                          ]),
                        ),
                        _addControl(context, ref, p, cart),
                      ]),
                    ),
                  ),
              ]),
      ),
    ]);
  }

  Widget _addControl(BuildContext context, WidgetRef ref, Product p, CartState cart) {
    final l = AppLocalizations.of(context);
    if (!p.available) {
      return Text(l.outOfStock, style: const TextStyle(color: Color(0xFFB3261E), fontSize: 12));
    }
    final qty = cart.shop?.id == shop.id ? (cart.items[p.id]?.qty ?? 0) : 0;
    if (qty == 0) {
      return IconButton.filled(
        onPressed: shop.acceptingOrders ? () => _add(context, ref, p) : null,
        icon: const Icon(Icons.add),
        style: IconButton.styleFrom(backgroundColor: Brand.green, foregroundColor: Colors.white),
      );
    }
    return Row(mainAxisSize: MainAxisSize.min, children: [
      IconButton(
          onPressed: () => ref.read(cartProvider.notifier).setQty(p.id, qty - 1), icon: const Icon(Icons.remove_circle_outline)),
      Text('$qty', style: const TextStyle(fontWeight: FontWeight.w800)),
      IconButton(
          onPressed: () => ref.read(cartProvider.notifier).setQty(p.id, qty + 1), icon: const Icon(Icons.add_circle, color: Brand.green)),
    ]);
  }
}
