import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../core/providers.dart';
import '../../core/theme.dart';
import '../../core/util.dart';
import '../../l10n/app_localizations.dart';
import '../../widgets/common.dart';

/// Mobile OTP login (customers and shop owners). Existing website owners can still use email + password.
class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});
  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen> {
  final _phone = TextEditingController();
  final _otp = TextEditingController();
  final _email = TextEditingController();
  final _pass = TextEditingController();
  bool _otpSent = false;
  bool _emailMode = false;
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _phone.dispose();
    _otp.dispose();
    _email.dispose();
    _pass.dispose();
    super.dispose();
  }

  Future<void> _run(Future<void> Function() job) async {
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await job();
    } catch (e) {
      if (mounted) setState(() => _error = errText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _sendOtp() async {
    final l = AppLocalizations.of(context);
    final n = normalizeMobile(_phone.text);
    if (n == null) {
      setState(() => _error = l.invalidMobile);
      return;
    }
    await _run(() async {
      await ref.read(clientProvider).auth.signInWithOtp(phone: '+91$n');
      if (mounted) setState(() => _otpSent = true);
    });
  }

  Future<void> _verify() async {
    final n = normalizeMobile(_phone.text);
    if (n == null) return;
    await _run(() async {
      await ref.read(clientProvider).auth.verifyOTP(phone: '+91$n', token: _otp.text.trim(), type: OtpType.sms);
      _done();
    });
  }

  Future<void> _emailLogin() async {
    await _run(() async {
      await ref.read(clientProvider).auth.signInWithPassword(email: _email.text.trim(), password: _pass.text);
      _done();
    });
  }

  void _done() {
    if (!mounted) return;
    ref.invalidate(profileProvider);
    ref.invalidate(myShopProvider);
    ref.invalidate(myOrdersProvider);
    if (context.canPop()) {
      context.pop();
    } else {
      context.go('/');
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text(l.login),
        actions: [IconButton(icon: const Icon(Icons.language), onPressed: () => showLanguageSheet(context, ref))],
      ),
      body: SafeArea(
        child: ListView(padding: const EdgeInsets.all(20), children: [
          const SizedBox(height: 12),
          const Icon(Icons.storefront, size: 64, color: Brand.green),
          const SizedBox(height: 8),
          Text(l.loginSubtitle, textAlign: TextAlign.center, style: const TextStyle(fontSize: 16)),
          const SizedBox(height: 24),
          if (!_emailMode) ...[
            TextField(
              controller: _phone,
              enabled: !_otpSent && !_busy,
              keyboardType: TextInputType.phone,
              maxLength: 10,
              decoration: deco(l.mobileNumber).copyWith(prefixText: '+91 ', counterText: ''),
            ),
            const SizedBox(height: 12),
            if (_otpSent) ...[
              TextField(
                controller: _otp,
                keyboardType: TextInputType.number,
                maxLength: 6,
                decoration: deco(l.enterOtp).copyWith(counterText: ''),
              ),
              const SizedBox(height: 12),
              FilledButton(onPressed: _busy ? null : _verify, child: Text(l.verify)),
              TextButton(
                onPressed: _busy
                    ? null
                    : () => setState(() {
                          _otpSent = false;
                          _otp.clear();
                        }),
                child: Text(l.retry),
              ),
            ] else
              FilledButton(onPressed: _busy ? null : _sendOtp, child: Text(l.sendOtp)),
          ] else ...[
            TextField(controller: _email, keyboardType: TextInputType.emailAddress, decoration: deco(l.email)),
            const SizedBox(height: 12),
            TextField(controller: _pass, obscureText: true, decoration: deco(l.password)),
            const SizedBox(height: 12),
            FilledButton(onPressed: _busy ? null : _emailLogin, child: Text(l.login)),
          ],
          if (_busy) const Padding(padding: EdgeInsets.only(top: 16), child: LinearProgressIndicator()),
          if (_error != null)
            Padding(
              padding: const EdgeInsets.only(top: 12),
              child: Text(_error!, textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFFB3261E))),
            ),
          const SizedBox(height: 16),
          TextButton(
            onPressed: _busy
                ? null
                : () => setState(() {
                      _emailMode = !_emailMode;
                      _error = null;
                    }),
            child: Text(_emailMode ? l.sendOtp : l.emailLogin, textAlign: TextAlign.center),
          ),
        ]),
      ),
    );
  }
}

/// Shown on screens that need an account.
class LoginPrompt extends StatelessWidget {
  const LoginPrompt({super.key});
  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.lock_outline, size: 56, color: Colors.black26),
          const SizedBox(height: 12),
          Text(l.loginRequired, textAlign: TextAlign.center, style: const TextStyle(fontSize: 16)),
          const SizedBox(height: 16),
          FilledButton(onPressed: () => context.push('/login'), child: Text(l.login)),
        ]),
      ),
    );
  }
}
