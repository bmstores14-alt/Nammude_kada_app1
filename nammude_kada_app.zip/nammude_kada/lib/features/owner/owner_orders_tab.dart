import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../core/providers.dart';
import '../../core/theme.dart';
import '../../core/util.dart';
import '../../data/models.dart';
import '../../data/repo.dart';
import '../../l10n/app_localizations.dart';
import '../../widgets/common.dart';

final ownerOrdersProvider = FutureProvider.autoDispose.family<List<ShopOrder>, int>(
    (ref, shopId) => ref.watch(repoProvider).ownerOrders(shopId));

class OwnerOrdersTab extends ConsumerStatefulWidget {
  const OwnerOrdersTab({super.key, required this.shop});
  final Shop shop;
  @override
  ConsumerState<OwnerOrdersTab> createState() => _OwnerOrdersTabState();
}

class _OwnerOrdersTabState extends ConsumerState<OwnerOrdersTab> {
  late final Repo _repo;
  RealtimeChannel? _channel;

  @override
  void initState() {
    super.initState();
    _repo = ref.read(repoProvider);
    // a new order (from the website or the app) appears here immediately
    _channel = _repo.watchOrders(widget.shop.id, () {
      if (mounted) ref.invalidate(ownerOrdersProvider(widget.shop.id));
    });
  }

  @override
  void dispose() {
    final ch = _channel;
    if (ch != null) _repo.stopWatching(ch);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    final id = widget.shop.id;
    return AsyncView<List<ShopOrder>>(
      value: ref.watch(ownerOrdersProvider(id)),
      onRetry: () => ref.invalidate(ownerOrdersProvider(id)),
      builder: (orders) {
        final now = DateTime.now();
        final today = orders.where((o) =>
            o.status != 'cancelled' &&
            o.createdAt.toLocal().year == now.year &&
            o.createdAt.toLocal().month == now.month &&
            o.createdAt.toLocal().day == now.day);
        final todayTotal = today.fold<int>(0, (a, o) => a + o.total);
        final newCount = orders.where((o) => o.status == 'new').length;
        return RefreshIndicator(
          onRefresh: () async {
            ref.invalidate(ownerOrdersProvider(id));
            await ref.read(ownerOrdersProvider(id).future).catchError((_) => <ShopOrder>[]);
          },
          child: ListView(padding: const EdgeInsets.all(12), children: [
            Row(children: [
              Expanded(child: _stat(l.todaySales, inr(todayTotal))),
              const SizedBox(width: 10),
              Expanded(child: _stat(l.newOrders, '$newCount', highlight: newCount > 0)),
            ]),
            const SizedBox(height: 8),
            if (orders.isEmpty)
              SizedBox(height: 280, child: EmptyState(icon: Icons.receipt_long_outlined, text: l.noOrdersYet))
            else
              for (final o in orders) _OrderTile(order: o, shopId: id),
          ]),
        );
      },
    );
  }

  Widget _stat(String label, String value, {bool highlight = false}) => Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: highlight ? Brand.yellow.withValues(alpha: 0.3) : Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(0x1A000000)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: const TextStyle(color: Colors.black54, fontSize: 12)),
          const SizedBox(height: 2),
          Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
        ]),
      );
}

class _OrderTile extends ConsumerWidget {
  const _OrderTile({required this.order, required this.shopId});
  final ShopOrder order;
  final int shopId;

  Future<void> _set(BuildContext context, WidgetRef ref, String status) async {
    final l = AppLocalizations.of(context);
    if (status == 'cancelled' && !await confirmDialog(context, '${l.reject}?')) return;
    try {
      await ref.read(repoProvider).updateOrderStatus(order.id, status);
      ref.invalidate(ownerOrdersProvider(shopId));
    } catch (e) {
      if (context.mounted) snack(context, errText(e));
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = AppLocalizations.of(context);
    final next = nextStatuses(order.status, order.fulfilment);
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      padding: const EdgeInsets.all(14),
      decoration: cardBox(),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(child: Text(order.code, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
          StatusChip(order.status),
        ]),
        Text(fmtDate(order.createdAt), style: const TextStyle(color: Colors.black54, fontSize: 12)),
        const SizedBox(height: 8),
        Text(order.customerName, style: const TextStyle(fontWeight: FontWeight.w700)),
        Text(order.fulfilment == 'delivery' ? '${l.delivery}: ${order.address}' : l.pickup,
            style: const TextStyle(color: Colors.black87)),
        if (order.notes.isNotEmpty) Text(order.notes, style: const TextStyle(color: Colors.black54, fontStyle: FontStyle.italic)),
        const SizedBox(height: 6),
        for (final i in order.items)
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Expanded(child: Text('${i.qty} × ${i.name}', maxLines: 1, overflow: TextOverflow.ellipsis)),
            Text(inr(i.unitPrice * i.qty)),
          ]),
        const Divider(),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(l.total, style: const TextStyle(fontWeight: FontWeight.w700)),
          Text(inr(order.total), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
        ]),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 4, children: [
          OutlinedButton.icon(
            onPressed: () => callNumber(order.customerPhone),
            icon: const Icon(Icons.call, size: 16),
            label: Text(l.callAction),
          ),
          OutlinedButton.icon(
            onPressed: () => openWhatsApp(
                order.customerPhone, '${order.customerName}, ${l.orderCodeLabel(order.code)}: ${statusLabel(l, order.status)}'),
            icon: const Icon(Icons.chat, size: 16),
            label: Text(l.whatsapp),
          ),
        ]),
        if (order.status == 'new') ...[
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: FilledButton(onPressed: () => _set(context, ref, 'confirmed'), child: Text(l.accept))),
            const SizedBox(width: 10),
            Expanded(
              child: OutlinedButton(
                style: OutlinedButton.styleFrom(foregroundColor: const Color(0xFFB3261E)),
                onPressed: () => _set(context, ref, 'cancelled'),
                child: Text(l.reject),
              ),
            ),
          ]),
        ] else if (next.isNotEmpty) ...[
          const SizedBox(height: 10),
          PopupMenuButton<String>(
            onSelected: (s) => _set(context, ref, s),
            itemBuilder: (c) => [for (final s in next) PopupMenuItem(value: s, child: Text(statusLabel(l, s)))],
            child: IgnorePointer(
              child: FilledButton.tonal(onPressed: () {}, child: Text(l.updateStatus)),
            ),
          ),
        ],
      ]),
    );
  }
}
