import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:share_plus/share_plus.dart';

import '../../core/config.dart';
import '../../core/media.dart';
import '../../core/providers.dart';
import '../../core/theme.dart';
import '../../core/util.dart';
import '../../data/models.dart';
import '../../l10n/app_localizations.dart';
import '../../widgets/common.dart';

class OwnerShopTab extends ConsumerStatefulWidget {
  const OwnerShopTab({super.key, required this.shop});
  final Shop shop;
  @override
  ConsumerState<OwnerShopTab> createState() => _OwnerShopTabState();
}

class _OwnerShopTabState extends ConsumerState<OwnerShopTab> {
  late bool _accepting = widget.shop.acceptingOrders;
  late bool _delivery = widget.shop.deliveryAvailable;
  late bool _pickup = widget.shop.pickupAvailable;
  late String? _logo = widget.shop.logo;
  late final _fee = TextEditingController(text: widget.shop.deliveryFee.toString());
  late final _min = TextEditingController(text: widget.shop.minOrder.toString());
  bool _busy = false;

  @override
  void dispose() {
    _fee.dispose();
    _min.dispose();
    super.dispose();
  }

  Future<void> _update(Map<String, dynamic> data) async {
    setState(() => _busy = true);
    try {
      await ref.read(repoProvider).updateShop(widget.shop.id, data);
      ref.invalidate(myShopProvider);
      if (mounted) snack(context, AppLocalizations.of(context).saved);
    } catch (e) {
      if (mounted) snack(context, errText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _pickLogo() async {
    try {
      final photo = await pickPhoto();
      if (photo == null) return;
      setState(() => _busy = true);
      final url = await ref.read(repoProvider).uploadImage(ref.read(userIdProvider)!, photo.bytes, photo.ext);
      await ref.read(repoProvider).updateShop(widget.shop.id, {'logo': url});
      ref.invalidate(myShopProvider);
      if (mounted) setState(() => _logo = url);
    } catch (e) {
      if (mounted) snack(context, errText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _gps() async {
    try {
      final p = await currentLatLng();
      await _update({'lat': p.lat, 'lng': p.lng});
    } catch (e) {
      if (mounted) snack(context, errText(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    final link = AppConfig.shopLink(widget.shop.slug);
    final shareText = '${widget.shop.name}\n$link';
    return ListView(padding: const EdgeInsets.all(16), children: [
      Container(
        padding: const EdgeInsets.all(14),
        decoration: cardBox(),
        child: Row(children: [
          GestureDetector(
            onTap: _busy ? null : _pickLogo,
            child: ClipRRect(borderRadius: BorderRadius.circular(12), child: NetImage(_logo, size: 72)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(widget.shop.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              Text('${widget.shop.place} · ${widget.shop.pincode}', style: const TextStyle(color: Colors.black54)),
            ]),
          ),
        ]),
      ),
      const SizedBox(height: 12),
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: Brand.yellow.withValues(alpha: 0.25), borderRadius: BorderRadius.circular(14)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(l.shareShop, style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          SelectableText(link),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: FilledButton.icon(
                onPressed: () => openUrl('https://wa.me/?text=${Uri.encodeComponent(shareText)}'),
                icon: const Icon(Icons.chat),
                label: Text(l.whatsapp),
              ),
            ),
            const SizedBox(width: 8),
            IconButton.outlined(onPressed: () => Share.share(shareText), icon: const Icon(Icons.share)),
          ]),
        ]),
      ),
      const SizedBox(height: 12),
      SwitchListTile(
        title: Text(l.acceptingOrders),
        value: _accepting,
        onChanged: _busy
            ? null
            : (v) {
                setState(() => _accepting = v);
                _update({'accepting_orders': v});
              },
      ),
      SwitchListTile(
        title: Text(l.delivery),
        value: _delivery,
        onChanged: _busy
            ? null
            : (v) {
                setState(() => _delivery = v);
                _update({'delivery_available': v});
              },
      ),
      SwitchListTile(
        title: Text(l.pickup),
        value: _pickup,
        onChanged: _busy
            ? null
            : (v) {
                setState(() => _pickup = v);
                _update({'pickup_available': v});
              },
      ),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(child: TextField(controller: _fee, keyboardType: TextInputType.number, decoration: deco(l.deliveryFee))),
        const SizedBox(width: 10),
        Expanded(child: TextField(controller: _min, keyboardType: TextInputType.number, decoration: deco(l.minOrder))),
      ]),
      const SizedBox(height: 10),
      FilledButton(
        onPressed: _busy
            ? null
            : () => _update({
                  'delivery_fee': (int.tryParse(_fee.text.trim()) ?? 0).clamp(0, 5000),
                  'min_order': (int.tryParse(_min.text.trim()) ?? 0).clamp(0, 100000),
                }),
        child: Text(l.save),
      ),
      const SizedBox(height: 10),
      OutlinedButton.icon(
        onPressed: _busy ? null : _gps,
        icon: Icon(widget.shop.lat == null ? Icons.my_location : Icons.check_circle, color: Brand.green),
        label: Text(l.setShopLocation),
      ),
      if (_busy) const Padding(padding: EdgeInsets.only(top: 12), child: LinearProgressIndicator()),
    ]);
  }
}
