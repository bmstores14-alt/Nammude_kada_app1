import 'package:flutter/material.dart';

import '../../core/theme.dart';
import '../../data/models.dart';
import '../../l10n/app_localizations.dart';
import 'owner_orders_tab.dart';
import 'owner_products_tab.dart';
import 'owner_shop_tab.dart';

class OwnerDashboard extends StatelessWidget {
  const OwnerDashboard({super.key, required this.shop});
  final Shop shop;

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: Text(shop.name),
          bottom: TabBar(
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            indicatorColor: Brand.yellow,
            tabs: [Tab(text: l.orders), Tab(text: l.products), Tab(text: l.myShop)],
          ),
        ),
        body: TabBarView(children: [
          OwnerOrdersTab(shop: shop),
          OwnerProductsTab(shop: shop),
          OwnerShopTab(shop: shop),
        ]),
      ),
    );
  }
}
