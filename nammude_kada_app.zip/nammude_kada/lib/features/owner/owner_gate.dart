import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/providers.dart';
import '../../l10n/app_localizations.dart';
import '../../widgets/common.dart';
import '../auth/login_screen.dart';
import 'owner_dashboard.dart';
import 'register_shop_screen.dart';

/// Decides what the "My shop" button shows: login, free shop registration, waiting for approval, or the dashboard.
class OwnerGate extends ConsumerWidget {
  const OwnerGate({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = AppLocalizations.of(context);
    if (ref.watch(userIdProvider) == null) {
      return Scaffold(appBar: AppBar(title: Text(l.myShop)), body: const LoginPrompt());
    }
    final shopAsync = ref.watch(myShopProvider);
    return shopAsync.when(
      loading: () => Scaffold(appBar: AppBar(title: Text(l.myShop)), body: const Loading()),
      error: (e, _) => Scaffold(
        appBar: AppBar(title: Text(l.myShop)),
        body: ErrorRetry(error: e, onRetry: () => ref.invalidate(myShopProvider)),
      ),
      data: (shop) {
        if (shop == null) return const RegisterShopScreen();
        if (shop.status == 'approved') return OwnerDashboard(shop: shop);
        final pending = shop.status == 'pending';
        return Scaffold(
          appBar: AppBar(title: Text(shop.name)),
          body: RefreshIndicator(
            onRefresh: () async => ref.invalidate(myShopProvider),
            child: ListView(children: [
              SizedBox(
                height: 360,
                child: EmptyState(
                  icon: pending ? Icons.hourglass_top : Icons.block,
                  text: pending
                      ? l.pendingApproval
                      : '${l.shopNotActive}${shop.statusNote.isEmpty ? '' : '\n\n${shop.statusNote}'}',
                ),
              ),
              Center(
                child: OutlinedButton(onPressed: () => ref.invalidate(myShopProvider), child: Text(l.retry)),
              ),
            ]),
          ),
        );
      },
    );
  }
}
