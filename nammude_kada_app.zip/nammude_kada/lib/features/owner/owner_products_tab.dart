import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/providers.dart';
import '../../core/router.dart';
import '../../core/theme.dart';
import '../../core/util.dart';
import '../../data/models.dart';
import '../../l10n/app_localizations.dart';
import '../../widgets/common.dart';

final ownerProductsProvider = FutureProvider.autoDispose.family<List<Product>, int>(
    (ref, shopId) => ref.watch(repoProvider).ownerProducts(shopId));

class OwnerProductsTab extends ConsumerWidget {
  const OwnerProductsTab({super.key, required this.shop});
  final Shop shop;

  Future<void> _edit(BuildContext context, WidgetRef ref, Product? p) async {
    await context.push('/owner/product', extra: ProductEditArgs(shop, p));
    ref.invalidate(ownerProductsProvider(shop.id));
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l = AppLocalizations.of(context);
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: Brand.yellow,
        foregroundColor: Brand.ink,
        onPressed: () => _edit(context, ref, null),
        icon: const Icon(Icons.add),
        label: Text(l.addProduct),
      ),
      body: AsyncView<List<Product>>(
        value: ref.watch(ownerProductsProvider(shop.id)),
        onRetry: () => ref.invalidate(ownerProductsProvider(shop.id)),
        builder: (items) => items.isEmpty
            ? EmptyState(icon: Icons.inventory_2_outlined, text: l.addProduct)
            : RefreshIndicator(
                onRefresh: () async {
                  ref.invalidate(ownerProductsProvider(shop.id));
                  await ref.read(ownerProductsProvider(shop.id).future).catchError((_) => <Product>[]);
                },
                child: ListView(padding: const EdgeInsets.fromLTRB(12, 12, 12, 90), children: [
                  for (final p in items)
                    InkWell(
                      onTap: () => _edit(context, ref, p),
                      child: Container(
                        margin: const EdgeInsets.symmetric(vertical: 5),
                        padding: const EdgeInsets.all(10),
                        decoration: cardBox(),
                        child: Row(children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: NetImage(p.images.isEmpty ? null : p.images.first, size: 60, fallback: Icons.shopping_bag),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(p.name, maxLines: 1, overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontWeight: FontWeight.w700)),
                              Text(inr(p.effectivePrice), style: const TextStyle(color: Brand.green, fontWeight: FontWeight.w700)),
                              if (p.stockQty != null)
                                Text('${l.stockQty.split(' (').first}: ${p.stockQty}',
                                    style: const TextStyle(color: Colors.black54, fontSize: 12)),
                            ]),
                          ),
                          Column(children: [
                            Switch(
                              value: p.inStock,
                              onChanged: (v) async {
                                try {
                                  await ref.read(repoProvider).setInStock(p.id, v);
                                  ref.invalidate(ownerProductsProvider(shop.id));
                                } catch (e) {
                                  if (context.mounted) snack(context, errText(e));
                                }
                              },
                            ),
                            Text(p.inStock ? l.inStock : l.outOfStock, style: const TextStyle(fontSize: 10)),
                          ]),
                        ]),
                      ),
                    ),
                ]),
              ),
      ),
    );
  }
}
