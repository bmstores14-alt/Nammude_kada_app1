import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/media.dart';
import '../../core/providers.dart';
import '../../core/theme.dart';
import '../../core/util.dart';
import '../../data/models.dart';
import '../../l10n/app_localizations.dart';
import '../../widgets/common.dart';

class ProductEditScreen extends ConsumerStatefulWidget {
  const ProductEditScreen({super.key, required this.shop, this.product});
  final Shop shop;
  final Product? product;
  @override
  ConsumerState<ProductEditScreen> createState() => _ProductEditScreenState();
}

class _ProductEditScreenState extends ConsumerState<ProductEditScreen> {
  final _form = GlobalKey<FormState>();
  late final _name = TextEditingController(text: widget.product?.name ?? '');
  late final _desc = TextEditingController(text: widget.product?.description ?? '');
  late final _price = TextEditingController(text: widget.product?.price.toString() ?? '');
  late final _discount = TextEditingController(text: widget.product?.discountPrice?.toString() ?? '');
  late final _unit = TextEditingController(text: widget.product?.unit ?? '');
  late final _stock = TextEditingController(text: widget.product?.stockQty?.toString() ?? '');
  late int? _category = widget.product?.categoryId ?? widget.shop.categoryId;
  late final List<String?> _images = [
    for (var i = 0; i < 3; i++) (widget.product != null && i < widget.product!.images.length) ? widget.product!.images[i] : null,
  ];
  bool _busy = false;

  @override
  void dispose() {
    for (final c in [_name, _desc, _price, _discount, _unit, _stock]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _pick(int slot) async {
    try {
      final photo = await pickPhoto();
      if (photo == null) return;
      setState(() => _busy = true);
      final uid = ref.read(userIdProvider)!;
      final url = await ref.read(repoProvider).uploadImage(uid, photo.bytes, photo.ext);
      if (mounted) setState(() => _images[slot] = url);
    } catch (e) {
      if (mounted) snack(context, errText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    final price = int.parse(_price.text.trim());
    final discount = _discount.text.trim().isEmpty ? null : int.tryParse(_discount.text.trim());
    final stock = _stock.text.trim().isEmpty ? null : int.tryParse(_stock.text.trim());
    final imgs = _images.whereType<String>().toList(); // keep photos packed to the front
    final data = <String, dynamic>{
      'name': _name.text.trim(),
      'description': _desc.text.trim(),
      'category_id': _category,
      'price': price,
      'discount_price': discount,
      'unit': _unit.text.trim(),
      'stock_qty': stock,
      'image': imgs.isNotEmpty ? imgs[0] : null,
      'image2': imgs.length > 1 ? imgs[1] : null,
      'image3': imgs.length > 2 ? imgs[2] : null,
    };
    setState(() => _busy = true);
    try {
      final p = widget.product;
      if (p == null) {
        data['shop_id'] = widget.shop.id;
        data['in_stock'] = true;
      }
      await ref.read(repoProvider).saveProduct(data, id: p?.id);
      if (mounted) context.pop();
    } catch (e) {
      // e.g. "Your plan allows 25 products" comes straight from the database
      if (mounted) snack(context, errText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _delete() async {
    final l = AppLocalizations.of(context);
    if (!await confirmDialog(context, '${l.delete}?', okLabel: l.delete)) return;
    setState(() => _busy = true);
    try {
      await ref.read(repoProvider).deleteProduct(widget.product!.id);
      if (mounted) context.pop();
    } catch (e) {
      if (mounted) snack(context, errText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    final lang = ref.watch(localeProvider).languageCode;
    final cats = ref.watch(categoriesProvider);
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.product == null ? l.addProduct : widget.product!.name),
        actions: [
          if (widget.product != null) IconButton(icon: const Icon(Icons.delete_outline), onPressed: _busy ? null : _delete),
        ],
      ),
      body: Form(
        key: _form,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          Text(l.photos, style: const TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          Row(children: [
            for (var i = 0; i < 3; i++)
              Padding(
                padding: const EdgeInsets.only(right: 10),
                child: GestureDetector(
                  onTap: _busy ? null : () => _pick(i),
                  child: Stack(children: [
                    Container(
                      width: 92,
                      height: 92,
                      decoration: cardBox(),
                      clipBehavior: Clip.antiAlias,
                      child: _images[i] == null
                          ? const Icon(Icons.add_a_photo_outlined, color: Colors.black38)
                          : NetImage(_images[i], size: 92),
                    ),
                    if (_images[i] != null)
                      Positioned(
                        right: 0,
                        top: 0,
                        child: InkWell(
                          onTap: () => setState(() => _images[i] = null),
                          child: const CircleAvatar(radius: 11, backgroundColor: Colors.black54, child: Icon(Icons.close, size: 14, color: Colors.white)),
                        ),
                      ),
                  ]),
                ),
              ),
          ]),
          const SizedBox(height: 16),
          TextFormField(
            controller: _name,
            decoration: deco(l.productName),
            validator: (v) => (v == null || v.trim().length < 2) ? l.requiredField : null,
          ),
          const SizedBox(height: 12),
          TextFormField(controller: _desc, maxLines: 3, maxLength: 1000, decoration: deco(l.description)),
          cats.maybeWhen(
            data: (items) => DropdownButtonFormField<int>(
              value: _category,
              isExpanded: true,
              decoration: deco(l.category),
              items: [for (final c in items) DropdownMenuItem(value: c.id, child: Text('${c.icon} ${c.name(lang)}'))],
              onChanged: (v) => setState(() => _category = v),
            ),
            orElse: () => const SizedBox.shrink(),
          ),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(
              child: TextFormField(
                controller: _price,
                keyboardType: TextInputType.number,
                decoration: deco(l.price),
                validator: (v) {
                  final n = int.tryParse(v?.trim() ?? '');
                  return (n == null || n < 1 || n > 1000000) ? l.requiredField : null;
                },
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: TextFormField(
                controller: _discount,
                keyboardType: TextInputType.number,
                decoration: deco(l.discountPrice),
                validator: (v) {
                  if (v == null || v.trim().isEmpty) return null;
                  final d = int.tryParse(v.trim());
                  final p = int.tryParse(_price.text.trim());
                  return (d == null || d < 1 || (p != null && d >= p)) ? l.requiredField : null;
                },
              ),
            ),
          ]),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: TextFormField(controller: _unit, maxLength: 30, decoration: deco(l.unitLabel).copyWith(counterText: ''))),
            const SizedBox(width: 10),
            Expanded(
              child: TextFormField(
                controller: _stock,
                keyboardType: TextInputType.number,
                decoration: deco(l.stockQty),
                validator: (v) => (v == null || v.trim().isEmpty || (int.tryParse(v.trim()) ?? -1) >= 0) ? null : l.requiredField,
              ),
            ),
          ]),
          const SizedBox(height: 20),
          FilledButton(onPressed: _busy ? null : _save, child: Text(l.save)),
          if (_busy) const Padding(padding: EdgeInsets.only(top: 12), child: LinearProgressIndicator()),
        ]),
      ),
    );
  }
}
