import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/media.dart';
import '../../core/providers.dart';
import '../../core/theme.dart';
import '../../core/util.dart';
import '../../data/models.dart';
import '../../l10n/app_localizations.dart';
import '../../widgets/common.dart';

/// Free shop registration for a logged-in user. The shop goes to the admin for approval.
class RegisterShopScreen extends ConsumerStatefulWidget {
  const RegisterShopScreen({super.key});
  @override
  ConsumerState<RegisterShopScreen> createState() => _RegisterShopScreenState();
}

class _RegisterShopScreenState extends ConsumerState<RegisterShopScreen> {
  final _form = GlobalKey<FormState>();
  final _shop = TextEditingController();
  final _owner = TextEditingController();
  final _town = TextEditingController();
  final _locality = TextEditingController();
  final _pin = TextEditingController();
  final _address = TextEditingController();
  final _whatsapp = TextEditingController();
  final _desc = TextEditingController();
  final _districtText = TextEditingController();
  String? _state;
  String? _district;
  int? _category;
  LatLng? _pos;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    final user = ref.read(clientProvider).auth.currentUser;
    final n = normalizeMobile(user?.phone);
    if (n != null) _whatsapp.text = n;
    ref.read(profileProvider.future).then((p) {
      if (mounted && p != null && _owner.text.isEmpty) _owner.text = p.fullName;
    });
  }

  @override
  void dispose() {
    for (final c in [_shop, _owner, _town, _locality, _pin, _address, _whatsapp, _desc, _districtText]) {
      c.dispose();
    }
    super.dispose();
  }

  String? _req(String? v) => (v == null || v.trim().length < 2) ? AppLocalizations.of(context).requiredField : null;

  Future<void> _gps() async {
    try {
      final p = await currentLatLng();
      if (mounted) setState(() => _pos = p);
    } catch (e) {
      if (mounted) snack(context, errText(e));
    }
  }

  Future<void> _submit(List<String> districts) async {
    if (!_form.currentState!.validate() || _state == null) {
      if (_state == null) snack(context, AppLocalizations.of(context).state);
      return;
    }
    setState(() => _busy = true);
    try {
      await ref.read(repoProvider).registerShop(
            name: _shop.text.trim(),
            ownerName: _owner.text.trim(),
            categoryId: _category,
            stateCode: _state!,
            district: districts.isEmpty ? _districtText.text.trim() : (_district ?? ''),
            town: _town.text.trim(),
            locality: _locality.text.trim(),
            pincode: _pin.text.trim(),
            address: _address.text.trim(),
            whatsapp: _whatsapp.text.trim(),
            description: _desc.text.trim(),
            lat: _pos?.lat,
            lng: _pos?.lng,
          );
      ref.invalidate(myShopProvider);
      ref.invalidate(profileProvider);
    } catch (e) {
      if (mounted) snack(context, errText(e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    final lang = ref.watch(localeProvider).languageCode;
    final states = ref.watch(statesProvider);
    final cats = ref.watch(categoriesProvider);
    final districts = _state == null ? const AsyncData<List<String>>([]) : ref.watch(districtsProvider(_state!));
    final districtList = districts.valueOrNull ?? const <String>[];

    return Scaffold(
      appBar: AppBar(title: Text(l.openFreeShop)),
      body: Form(
        key: _form,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: Brand.yellow.withValues(alpha: 0.25), borderRadius: BorderRadius.circular(12)),
            child: Text(l.freeShopNote, style: const TextStyle(fontWeight: FontWeight.w600)),
          ),
          const SizedBox(height: 16),
          TextFormField(controller: _shop, decoration: deco(l.shopName), validator: _req),
          const SizedBox(height: 12),
          TextFormField(controller: _owner, decoration: deco(l.ownerName), validator: _req),
          const SizedBox(height: 12),
          cats.maybeWhen(
            data: (items) => DropdownButtonFormField<int>(
              value: _category,
              decoration: deco(l.category),
              items: [for (final c in items) DropdownMenuItem(value: c.id, child: Text('${c.icon} ${c.name(lang)}'))],
              onChanged: (v) => setState(() => _category = v),
            ),
            orElse: () => const LinearProgressIndicator(),
          ),
          const SizedBox(height: 12),
          states.maybeWhen(
            data: (items) => DropdownButtonFormField<String>(
              value: _state,
              isExpanded: true,
              decoration: deco(l.state),
              items: [for (final s in items) DropdownMenuItem(value: s.code, child: Text(s.name))],
              onChanged: (v) => setState(() {
                _state = v;
                _district = null;
              }),
            ),
            orElse: () => const LinearProgressIndicator(),
          ),
          const SizedBox(height: 12),
          if (districtList.isNotEmpty)
            DropdownButtonFormField<String>(
              value: _district,
              isExpanded: true,
              decoration: deco(l.district),
              items: [for (final d in districtList) DropdownMenuItem(value: d, child: Text(d))],
              onChanged: (v) => setState(() => _district = v),
            )
          else
            TextFormField(controller: _districtText, decoration: deco(l.district)),
          const SizedBox(height: 12),
          TextFormField(controller: _town, decoration: deco(l.town), validator: _req),
          const SizedBox(height: 12),
          TextFormField(
            controller: _pin,
            keyboardType: TextInputType.number,
            maxLength: 6,
            decoration: deco(l.pincode).copyWith(counterText: ''),
            validator: (v) => RegExp(r'^[0-9]{6}$').hasMatch(v?.trim() ?? '') ? null : l.requiredField,
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _address,
            maxLines: 2,
            decoration: deco(l.address),
            validator: (v) => (v == null || v.trim().length < 6) ? l.requiredField : null,
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _whatsapp,
            keyboardType: TextInputType.phone,
            decoration: deco(l.whatsappNumber).copyWith(prefixText: '+91 '),
            validator: (v) => normalizeMobile(v) == null ? l.invalidMobile : null,
          ),
          const SizedBox(height: 12),
          TextFormField(controller: _desc, maxLines: 3, maxLength: 600, decoration: deco(l.description)),
          OutlinedButton.icon(
            onPressed: _gps,
            icon: Icon(_pos == null ? Icons.my_location : Icons.check_circle, color: Brand.green),
            label: Text(l.setShopLocation),
          ),
          const SizedBox(height: 16),
          FilledButton(onPressed: _busy ? null : () => _submit(districtList), child: Text(l.submit)),
          if (_busy) const Padding(padding: EdgeInsets.only(top: 12), child: LinearProgressIndicator()),
        ]),
      ),
    );
  }
}
