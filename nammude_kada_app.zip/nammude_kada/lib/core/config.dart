class AppConfig {
  static const tagline = 'Every Small Shop, One Digital Platform.';

  /// Passed at build time:  --dart-define-from-file=env.json
  /// env.json = {"SUPABASE_URL": "...", "SUPABASE_ANON_KEY": "..."}   (anon key only, never service_role)
  static const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
  static const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');

  static const siteBase = 'https://www.nammudekada.store';
  // The website uses hash routes: #/s/<slug> is a shop page.
  static String shopLink(String slug) => '$siteBase/#/s/$slug';
  static const privacyUrl = '$siteBase/#/privacy';
  static const termsUrl = '$siteBase/#/terms';

  /// code -> name written in its own language
  static const languages = <String, String>{
    'en': 'English',
    'ml': 'മലയാളം',
    'hi': 'हिन्दी',
    'ta': 'தமிழ்',
    'kn': 'ಕನ್ನಡ',
    'te': 'తెలుగు',
    'mr': 'मराठी',
    'bn': 'বাংলা',
    'gu': 'ગુજરાતી',
    'pa': 'ਪੰਜਾਬੀ',
  };
}
