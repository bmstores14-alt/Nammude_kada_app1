import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import '../l10n/app_localizations.dart';

final _money = NumberFormat.decimalPattern('en_IN');
String inr(num n) => '₹${_money.format(n.round())}';

String fmtDate(DateTime d) => DateFormat('d MMM, h:mm a').format(d.toLocal());

/// Human-readable text for an error. Database rules (stock, limits...) already raise readable messages.
String errText(Object e) {
  if (e is PostgrestException) return e.message;
  if (e is AuthException) return e.message;
  final s = e.toString();
  return s.startsWith('Exception: ') ? s.substring(11) : s;
}

void snack(BuildContext context, String msg) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(msg)));
}

/// 10-digit Indian mobile number from anything the user typed or the auth phone (91XXXXXXXXXX)
String? normalizeMobile(String? raw) {
  var d = (raw ?? '').replaceAll(RegExp(r'\D'), '');
  if (d.length == 12 && d.startsWith('91')) d = d.substring(2);
  if (d.length == 11 && d.startsWith('0')) d = d.substring(1);
  return RegExp(r'^[6-9][0-9]{9}$').hasMatch(d) ? d : null;
}

Future<void> openUrl(String url) async {
  await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
}

Future<void> callNumber(String number) => openUrl('tel:+91$number');

Future<void> openWhatsApp(String number, [String text = '']) =>
    openUrl('https://wa.me/91$number${text.isEmpty ? '' : '?text=${Uri.encodeComponent(text)}'}');

String statusLabel(AppLocalizations l, String s) {
  switch (s) {
    case 'new':
      return l.statusNew;
    case 'confirmed':
      return l.statusConfirmed;
    case 'preparing':
      return l.statusPreparing;
    case 'ready':
      return l.statusReady;
    case 'out_for_delivery':
      return l.statusOutForDelivery;
    case 'delivered':
      return l.statusDelivered;
    case 'cancelled':
      return l.statusCancelled;
    default:
      return s;
  }
}

Color statusColor(String s) {
  switch (s) {
    case 'new':
      return const Color(0xFFE08A00);
    case 'delivered':
      return const Color(0xFF0F6B3E);
    case 'cancelled':
      return const Color(0xFFB3261E);
    default:
      return const Color(0xFF1565C0);
  }
}

/// Which statuses an owner may move an order to from the current one.
List<String> nextStatuses(String current, String fulfilment) {
  switch (current) {
    case 'new':
      return ['confirmed', 'cancelled'];
    case 'confirmed':
      return ['preparing', 'ready', 'cancelled'];
    case 'preparing':
      return ['ready', 'cancelled'];
    case 'ready':
      return [if (fulfilment == 'delivery') 'out_for_delivery', 'delivered', 'cancelled'];
    case 'out_for_delivery':
      return ['delivered', 'cancelled'];
    default:
      return const [];
  }
}

Future<bool> confirmDialog(BuildContext context, String message, {String? okLabel}) async {
  final l = AppLocalizations.of(context);
  final r = await showDialog<bool>(
    context: context,
    builder: (c) => AlertDialog(
      content: Text(message),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: Text(l.cancelAction)),
        TextButton(onPressed: () => Navigator.pop(c, true), child: Text(okLabel ?? l.confirm)),
      ],
    ),
  );
  return r ?? false;
}
