import 'dart:ui' show PlatformDispatcher;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../data/models.dart';
import '../data/repo.dart';
import 'config.dart';

final prefsProvider = Provider<SharedPreferences>((ref) => throw UnimplementedError('prefs not ready'));
final clientProvider = Provider<SupabaseClient>((ref) => Supabase.instance.client);
final repoProvider = Provider<Repo>((ref) => Repo(ref.watch(clientProvider)));

/// Current login session (null = browsing as a guest).
final sessionProvider = StreamProvider<Session?>((ref) async* {
  final c = ref.watch(clientProvider);
  yield c.auth.currentSession;
  await for (final s in c.auth.onAuthStateChange) {
    yield s.session;
  }
});

final userIdProvider = Provider<String?>((ref) {
  final s = ref.watch(sessionProvider);
  return s.valueOrNull?.user.id ?? ref.watch(clientProvider).auth.currentUser?.id;
});

final tabProvider = StateProvider<int>((ref) => 0);
final locationProvider = StateProvider<LatLng?>((ref) => null);

class LocaleNotifier extends StateNotifier<Locale> {
  LocaleNotifier(this._prefs) : super(_initial(_prefs));
  final SharedPreferences _prefs;

  static Locale _initial(SharedPreferences p) {
    final saved = p.getString('lang');
    if (saved != null && AppConfig.languages.containsKey(saved)) return Locale(saved);
    final device = PlatformDispatcher.instance.locale.languageCode;
    return Locale(AppConfig.languages.containsKey(device) ? device : 'en');
  }

  Future<void> set(String code) async {
    if (!AppConfig.languages.containsKey(code)) return;
    state = Locale(code);
    await _prefs.setString('lang', code);
  }
}

final localeProvider = StateNotifierProvider<LocaleNotifier, Locale>((ref) => LocaleNotifier(ref.watch(prefsProvider)));

final profileProvider = FutureProvider.autoDispose<Profile?>((ref) async {
  final uid = ref.watch(userIdProvider);
  if (uid == null) return null;
  return ref.read(repoProvider).myProfile(uid);
});

final myShopProvider = FutureProvider.autoDispose<Shop?>((ref) async {
  final uid = ref.watch(userIdProvider);
  if (uid == null) return null;
  return ref.read(repoProvider).myShop(uid);
});

final categoriesProvider = FutureProvider<List<Category>>((ref) => ref.watch(repoProvider).categories());
final statesProvider = FutureProvider<List<StateItem>>((ref) => ref.watch(repoProvider).states());
final districtsProvider =
    FutureProvider.family<List<String>, String>((ref, code) => ref.watch(repoProvider).districts(code));

class ShopQuery {
  const ShopQuery({this.text = '', this.categoryId, this.lat, this.lng});
  final String text;
  final int? categoryId;
  final double? lat;
  final double? lng;

  @override
  bool operator ==(Object o) =>
      o is ShopQuery && o.text == text && o.categoryId == categoryId && o.lat == lat && o.lng == lng;
  @override
  int get hashCode => Object.hash(text, categoryId, lat, lng);
}

final shopsProvider = FutureProvider.autoDispose.family<List<Shop>, ShopQuery>((ref, q) {
  final repo = ref.watch(repoProvider);
  if (q.lat != null && q.lng != null) return repo.nearbyShops(q.lat!, q.lng!);
  return repo.shops(text: q.text, categoryId: q.categoryId);
});

final featuredShopsProvider = FutureProvider.autoDispose<List<Shop>>((ref) => ref.watch(repoProvider).featuredShops());

final shopBySlugProvider =
    FutureProvider.autoDispose.family<Shop?, String>((ref, slug) => ref.watch(repoProvider).shopBySlug(slug));

final shopProductsProvider = FutureProvider.autoDispose.family<List<Product>, int>(
    (ref, shopId) => ref.watch(repoProvider).productsOfShop(shopId));

final productSearchProvider = FutureProvider.autoDispose.family<List<Product>, String>(
    (ref, text) => ref.watch(repoProvider).searchProducts(text));

final myOrdersProvider = FutureProvider.autoDispose<List<MyOrder>>((ref) {
  final uid = ref.watch(userIdProvider);
  if (uid == null) return Future.value(<MyOrder>[]);
  return ref.watch(repoProvider).myOrders();
});

// ---------- cart (one shop at a time, like the website) ----------
class CartState {
  const CartState({this.shop, this.items = const {}});
  final Shop? shop;
  final Map<int, CartItem> items;

  int get count => items.values.fold(0, (a, i) => a + i.qty);
  int get subtotal => items.values.fold(0, (a, i) => a + i.product.effectivePrice * i.qty);
}

class CartNotifier extends StateNotifier<CartState> {
  CartNotifier() : super(const CartState());

  bool canAdd(Shop shop) => state.shop == null || state.shop!.id == shop.id || state.items.isEmpty;

  void add(Shop shop, Product p) {
    if (!canAdd(shop)) return;
    final items = Map<int, CartItem>.from(state.items);
    final cur = items[p.id];
    final max = p.stockQty;
    final next = (cur?.qty ?? 0) + 1;
    if (max != null && next > max) return;
    if (next > 99) return;
    items[p.id] = CartItem(p, next);
    state = CartState(shop: shop, items: items);
  }

  void setQty(int productId, int qty) {
    final items = Map<int, CartItem>.from(state.items);
    final cur = items[productId];
    if (cur == null) return;
    final max = cur.product.stockQty;
    if (qty <= 0) {
      items.remove(productId);
    } else {
      items[productId] = CartItem(cur.product, (max != null && qty > max) ? max : qty.clamp(1, 99));
    }
    state = CartState(shop: items.isEmpty ? null : state.shop, items: items);
  }

  void clear() => state = const CartState();
}

final cartProvider = StateNotifierProvider<CartNotifier, CartState>((ref) => CartNotifier());
