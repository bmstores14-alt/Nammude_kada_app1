import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../data/models.dart';
import '../features/auth/login_screen.dart';
import '../features/cart/checkout_screen.dart';
import '../features/home/root_screen.dart';
import '../features/home/search_screen.dart';
import '../features/home/shops_screen.dart';
import '../features/owner/owner_gate.dart';
import '../features/owner/product_edit_screen.dart';
import '../features/owner/register_shop_screen.dart';
import '../features/shop/shop_screen.dart';
import 'providers.dart';

class ProductEditArgs {
  ProductEditArgs(this.shop, this.product);
  final Shop shop;
  final Product? product;
}

final routerProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    routes: [
      GoRoute(path: '/', builder: (c, s) => const RootScreen()),
      GoRoute(path: '/login', builder: (c, s) => const LoginScreen()),
      GoRoute(
        path: '/shops',
        builder: (c, s) {
          final q = s.uri.queryParameters;
          final lat = double.tryParse(q['lat'] ?? '');
          final lng = double.tryParse(q['lng'] ?? '');
          return ShopsScreen(
            title: q['title'] ?? '',
            query: ShopQuery(text: q['q'] ?? '', categoryId: int.tryParse(q['cat'] ?? ''), lat: lat, lng: lng),
          );
        },
      ),
      GoRoute(path: '/search', builder: (c, s) => SearchScreen(initial: s.uri.queryParameters['q'] ?? '')),
      GoRoute(path: '/shop/:slug', builder: (c, s) => ShopScreen(slug: s.pathParameters['slug']!)),
      // same page, path-style link (for future Android App Links)
      GoRoute(path: '/s/:slug', builder: (c, s) => ShopScreen(slug: s.pathParameters['slug']!)),
      GoRoute(path: '/checkout', builder: (c, s) => const CheckoutScreen()),
      GoRoute(path: '/owner', builder: (c, s) => const OwnerGate()),
      GoRoute(path: '/register-shop', builder: (c, s) => const RegisterShopScreen()),
      GoRoute(
        path: '/owner/product',
        builder: (c, s) {
          final a = s.extra as ProductEditArgs;
          return ProductEditScreen(shop: a.shop, product: a.product);
        },
      ),
    ],
  );
});
