import 'dart:typed_data';

import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';

import '../data/models.dart';

class PickedPhoto {
  PickedPhoto(this.bytes, this.ext);
  final Uint8List bytes;
  final String ext;
}

/// Gallery photo, shrunk before upload (the storage bucket accepts JPG/PNG/WebP up to 2 MB).
Future<PickedPhoto?> pickPhoto() async {
  final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1280, imageQuality: 80);
  if (x == null) return null;
  final ext = x.name.contains('.') ? x.name.split('.').last.toLowerCase() : 'jpg';
  if (!const ['jpg', 'jpeg', 'png', 'webp'].contains(ext)) {
    throw Exception('Please choose a JPG, PNG or WebP photo.');
  }
  return PickedPhoto(await x.readAsBytes(), ext);
}

Future<LatLng> currentLatLng() async {
  var perm = await Geolocator.checkPermission();
  if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
  if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) {
    throw Exception('Location permission is needed.');
  }
  final pos = await Geolocator.getCurrentPosition(
    locationSettings: const LocationSettings(accuracy: LocationAccuracy.high),
  );
  return LatLng(pos.latitude, pos.longitude);
}
