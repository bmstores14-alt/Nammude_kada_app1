import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../core/theme.dart';
import '../data/models.dart';
import '../l10n/app_localizations.dart';
import 'common.dart';

class ShopCard extends StatelessWidget {
  const ShopCard({super.key, required this.shop});
  final Shop shop;

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: () => context.push('/shop/${Uri.encodeComponent(shop.slug)}'),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        padding: const EdgeInsets.all(12),
        decoration: cardBox(),
        child: Row(children: [
          ClipRRect(borderRadius: BorderRadius.circular(12), child: NetImage(shop.logo, size: 64)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(shop.name, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              const SizedBox(height: 2),
              Text(
                [shop.place, shop.pincode].where((s) => s.isNotEmpty).join(' · ') +
                    (shop.distanceKm != null ? ' · ${shop.distanceKm!.toStringAsFixed(1)} km' : ''),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.black54),
              ),
              const SizedBox(height: 6),
              Wrap(spacing: 6, runSpacing: 4, children: [
                if (shop.deliveryAvailable) _tag(l.delivery, Brand.green),
                if (shop.pickupAvailable) _tag(l.pickup, Colors.black54),
              ]),
            ]),
          ),
          const Icon(Icons.chevron_right, color: Colors.black38),
        ]),
      ),
    );
  }

  Widget _tag(String t, Color c) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
        decoration: BoxDecoration(color: c.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(8)),
        child: Text(t, style: TextStyle(color: c, fontSize: 11, fontWeight: FontWeight.w600)),
      );
}
