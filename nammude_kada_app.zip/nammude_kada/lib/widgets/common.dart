import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/config.dart';
import '../core/providers.dart';
import '../core/theme.dart';
import '../core/util.dart';
import '../l10n/app_localizations.dart';

class Loading extends StatelessWidget {
  const Loading({super.key});
  @override
  Widget build(BuildContext context) =>
      const Center(child: Padding(padding: EdgeInsets.all(32), child: CircularProgressIndicator()));
}

class ErrorRetry extends StatelessWidget {
  const ErrorRetry({super.key, required this.error, required this.onRetry});
  final Object error;
  final VoidCallback onRetry;
  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.cloud_off, size: 40, color: Colors.black45),
          const SizedBox(height: 8),
          Text(l.somethingWrong, style: const TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 4),
          Text(errText(error), textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54)),
          const SizedBox(height: 12),
          OutlinedButton(onPressed: onRetry, child: Text(l.retry)),
        ]),
      ),
    );
  }
}

class EmptyState extends StatelessWidget {
  const EmptyState({super.key, required this.icon, required this.text});
  final IconData icon;
  final String text;
  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, size: 56, color: Colors.black26),
            const SizedBox(height: 12),
            Text(text, textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54, fontSize: 16)),
          ]),
        ),
      );
}

/// Shows loading / error+retry / data for any AsyncValue.
class AsyncView<T> extends StatelessWidget {
  const AsyncView({super.key, required this.value, required this.onRetry, required this.builder});
  final AsyncValue<T> value;
  final VoidCallback onRetry;
  final Widget Function(T data) builder;
  @override
  Widget build(BuildContext context) => value.when(
        data: builder,
        loading: () => const Loading(),
        error: (e, _) => ErrorRetry(error: e, onRetry: onRetry),
      );
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.text, {super.key});
  final String text;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 8),
        child: Text(text, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: Brand.ink)),
      );
}

class NetImage extends StatelessWidget {
  const NetImage(this.url, {super.key, this.size, this.fit = BoxFit.cover, this.fallback = Icons.storefront});
  final String? url;
  final double? size;
  final BoxFit fit;
  final IconData fallback;
  @override
  Widget build(BuildContext context) {
    final ph = Container(
      width: size,
      height: size,
      color: const Color(0xFFEFEBDD),
      child: Icon(fallback, color: Colors.black26, size: (size ?? 48) * 0.5),
    );
    if (url == null || url!.isEmpty) return ph;
    return CachedNetworkImage(
      imageUrl: url!,
      width: size,
      height: size,
      fit: fit,
      placeholder: (_, __) => ph,
      errorWidget: (_, __, ___) => ph,
    );
  }
}

class StatusChip extends StatelessWidget {
  const StatusChip(this.status, {super.key});
  final String status;
  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context);
    final c = statusColor(status);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(color: c.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(20)),
      child: Text(statusLabel(l, status), style: TextStyle(color: c, fontWeight: FontWeight.w700, fontSize: 12)),
    );
  }
}

/// Bottom sheet to change the app language (all 10 languages, each in its own script).
Future<void> showLanguageSheet(BuildContext context, WidgetRef ref) {
  final current = ref.read(localeProvider).languageCode;
  return showModalBottomSheet(
    context: context,
    showDragHandle: true,
    builder: (c) => SafeArea(
      child: ListView(
        shrinkWrap: true,
        children: [
          for (final e in AppConfig.languages.entries)
            ListTile(
              title: Text(e.value, style: const TextStyle(fontSize: 18)),
              trailing: e.key == current ? const Icon(Icons.check, color: Brand.green) : null,
              onTap: () async {
                Navigator.pop(c);
                await ref.read(localeProvider.notifier).set(e.key);
                if (ref.read(userIdProvider) != null) {
                  try {
                    await ref.read(repoProvider).updateProfile('', e.key);
                  } catch (_) {}
                }
              },
            ),
        ],
      ),
    ),
  );
}
